// Виконується в кожному фреймі. Реагує ТІЛЬКИ на повідомлення від сторінки розширення
// (перевіряється origin) і виконує: назад / вперед / перезавантажити / повернути поточну адресу.
(() => {
  const api = typeof browser !== "undefined" ? browser : chrome;
  let origin;
  try {
    origin = api.runtime.getURL("").replace(/\/$/, "");
  } catch (e) {
    return;
  }
  window.addEventListener("message", (e) => {
    const d = e.data;
    if (!d || d.__sis !== 1 || e.origin !== origin) return;
    if (e.source) {
      e.source.postMessage({ __sis: 1, cmd: d.cmd, ack: true, href: location.href }, e.origin);
    }
    if (d.cmd === "back") history.back();
    else if (d.cmd === "forward") history.forward();
    else if (d.cmd === "reload") location.reload();
    else if (d.cmd === "fix-layout") runTool('layout');
    else if (d.cmd === "translit") runTool('translit');
  });

  // --- Text Tools: Layout Fixer & Translit CMU 2010 ---
  const EN = "qwertyuiop[]asdfghjkl;'zxcvbnm,./`\\" + 'QWERTYUIOP{}ASDFGHJKL:\"ZXCVBNM<>?~|';
  const UK = "йцукенгшщзхїфівапролджєячсмитьбю.'ґ" + "ЙЦУКЕНГШЩЗХЇФІВАПРОЛДЖЄЯЧСМИТЬБЮ,ʼҐ";

  const enToUk = {};
  const ukToEn = {};
  for (let i = 0; i < EN.length; i++) {
    enToUk[EN[i]] = UK[i];
    if (/[а-щьюяєіїґА-ЩЬЮЯЄІЇҐ]/.test(UK[i])) ukToEn[UK[i]] = EN[i];
  }
  ukToEn["'"] = "`";

  function convertLayout(text) {
    const latin = (text.match(/[A-Za-z]/g) || []).length;
    const cyr = (text.match(/[А-Яа-яЄєІіЇїҐґ]/g) || []).length;
    const map = latin >= cyr ? enToUk : ukToEn;
    return Array.from(text, ch => map[ch] ?? ch).join("");
  }

  function transliterate(str) {
    let res = str.replace(/(^|[^А-Яа-яЄєІіЇїҐґ])([ЄєЇїЙйЮюЯя])/g, (m, p, l) => {
      const sm = {'Є':'Ye','є':'ye','Ї':'Yi','ї':'yi','Й':'Y','й':'y','Ю':'Yu','ю':'yu','Я':'Ya','я':'ya'};
      return p + sm[l];
    });
    res = res.replace(/Зг/g, "Zgh").replace(/ЗГ/g, "ZGH").replace(/зг/g, "zgh");
    const map = {
      'А':'A','а':'a','Б':'B','б':'b','В':'V','в':'v','Г':'H','г':'h','Ґ':'G','ґ':'g',
      'Д':'D','д':'d','Е':'E','е':'e','Ж':'Zh','ж':'zh','З':'Z','з':'z','И':'Y','и':'y',
      'І':'I','і':'i','К':'K','к':'k','Л':'L','л':'l','М':'M','м':'m','Н':'N','н':'n',
      'О':'O','о':'o','П':'P','п':'p','Р':'R','р':'r','С':'S','с':'s','Т':'T','т':'t',
      'У':'U','у':'u','Ф':'F','ф':'f','Х':'Kh','х':'kh','Ц':'Ts','ц':'ts','Ч':'Ch','ч':'ch',
      'Ш':'Sh','ш':'sh','Щ':'Shch','щ':'shch',
      'Є':'Ie','є':'ie','Ї':'I','ї':'i','Й':'I','й':'i','Ю':'Iu','ю':'iu','Я':'Ia','я':'ia'
    };
    res = res.replace(/[А-ЩЬЮЯа-щьюяҐґІіЇїЄє]/g, (m) => map[m] || m);
    res = res.replace(/['ʼьЬ]/g, '');
    return res;
  }

  function processText(el, type) {
    let start = el.selectionStart, end = el.selectionEnd;
    if (start === end) { start = 0; end = el.value.length; }
    const text = el.value.slice(start, end);
    const fixed = type === 'translit' ? transliterate(text) : convertLayout(text);
    el.setRangeText(fixed, start, end, "select");
    el.dispatchEvent(new Event("input", { bubbles: true }));
  }

  function processEditable(root, type) {
    const sel = window.getSelection();
    if (sel.isCollapsed) {
      const range = document.createRange();
      range.selectNodeContents(root);
      sel.removeAllRanges();
      sel.addRange(range);
    }
    const text = sel.toString();
    const fixed = type === 'translit' ? transliterate(text) : convertLayout(text);
    document.execCommand("insertText", false, fixed);
  }

  // Firefox може доставити і команду розширення, і keydown — не виконуємо інструмент двічі
  let lastRun = 0;
  function runTool(type) {
    const now = Date.now();
    if (now - lastRun < 250) return true;
    const el = document.activeElement;
    if (!el) return false;
    lastRun = now;
    if ((el.tagName === "TEXTAREA") ||
        (el.tagName === "INPUT" && /^(text|search|url|email)?$/.test(el.type))) {
      processText(el, type);
      return true;
    }
    if (el.isContentEditable) {
      processEditable(el, type);
      return true;
    }
    return false;
  }

  document.addEventListener("keydown", e => {
    if (e.altKey && !e.ctrlKey && !e.metaKey) {
      if (e.code === "KeyZ") {
        if (runTool('layout')) e.preventDefault();
      } else if (e.code === "KeyT") {
        if (runTool('translit')) e.preventDefault();
      }
    }
  }, true);

  api.runtime.onMessage.addListener((msg) => {
    if (msg && (msg.cmd === "fix-layout" || msg.cmd === "translit")) {
      runTool(msg.cmd);
    }
  });

})();
