importScripts("compat.js", "i18n.js");

// Версія для Chromium (Chrome, Edge, Brave): MV3 service worker, sidePanel, declarativeNetRequest.
// Service worker може «засинати», тому стан, що має пережити сон, лежить у storage, а таймери — у chrome.alarms.

browser.runtime.onInstalled.addListener(async () => {
  const { sites } = await browser.storage.local.get("sites");
  if (!sites) {
    await browser.storage.local.set({ sites: [], activeId: null });
  }
});

// --- Контекстне меню (з підменю тек, якщо теки є) ---
const MENU_KINDS = [
  { key: "link", tkey: "menuLink", contexts: ["link"] },
  { key: "page", tkey: "menuPage", contexts: ["page", "frame"] },
  { key: "tab", tkey: "menuTab", contexts: ["action"] }
];

let rebuilding = Promise.resolve();
function rebuildMenus() {
  // послідовно, щоб швидкі зміни сховища не створювали дублікатів id
  rebuilding = rebuilding.then(doRebuildMenus).catch((e) => console.error("rebuildMenus failed:", e));
  return rebuilding;
}

async function doRebuildMenus() {
  const { folders = [] } = await browser.storage.local.get("folders");
  await loadLang();
  await chrome.contextMenus.removeAll();
  for (const k of MENU_KINDS) {
    if (!folders.length) {
      chrome.contextMenus.create({ id: "add-" + k.key + "|", title: t(k.tkey), contexts: k.contexts });
      continue;
    }
    chrome.contextMenus.create({ id: "parent-" + k.key, title: t(k.tkey), contexts: k.contexts });
    chrome.contextMenus.create({
      id: "add-" + k.key + "|", parentId: "parent-" + k.key,
      title: t("noFolder"), contexts: k.contexts
    });
    for (const f of folders) {
      chrome.contextMenus.create({
        id: "add-" + k.key + "|" + f.id, parentId: "parent-" + k.key,
        title: "📁 " + f.name.replace(/&/g, "&&"), contexts: k.contexts
      });
    }
  }
  chrome.contextMenus.create({ id: "fix-layout", title: "Виправити розкладку (Alt+Z)", contexts: ["editable"] });
  chrome.contextMenus.create({ id: "translit", title: "Транслітерувати КМУ 2010 (Alt+T)", contexts: ["editable"] });
}
rebuildMenus();
browser.storage.onChanged.addListener((ch, area) => {
  if (area !== "local") return;
  if (ch.folders || ch.lang) rebuildMenus();
  if (ch.sites) updateWorkerRule().catch((e) => console.error("updateWorkerRule failed:", e));
});

// --- Відкриті панелі: windowId -> port (живе, поки service worker не заснув; панель сама перепідключається) ---
const openPanels = new Map();
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "my-sidebar-panel") return;
  let wid = null;
  port.onMessage.addListener((m) => {
    if (m && m.windowId != null) { wid = m.windowId; openPanels.set(wid, port); }
  });
  port.onDisconnect.addListener(() => {
    if (wid != null && openPanels.get(wid) === port) openPanels.delete(wid);
  });
});

function sendTool(cmd, tabId, frameId) {
  openPanels.forEach((port) => { try { port.postMessage({ cmd }); } catch (e) {} });
  if (tabId != null && tabId >= 0) {
    chrome.tabs.sendMessage(tabId, { cmd }, frameId ? { frameId } : undefined).catch(() => {});
  }
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const id = String(info.menuItemId);
  if (id === "fix-layout" || id === "translit") {
    sendTool(id, tab && tab.id, info.frameId || 0);
    return;
  }
  // sidePanel.open() дозволено тільки поки діє жест користувача — тому першим ділом
  try { if (tab && tab.windowId != null) chrome.sidePanel.open({ windowId: tab.windowId }); } catch (e) {}

  const [kind, folderId] = id.split("|");
  let url, title;
  if (kind === "add-link") {
    url = info.linkUrl;
    title = (info.linkText || "").trim();
  } else if (kind === "add-page") {
    url = info.frameUrl || info.pageUrl || (tab && tab.url);
    title = tab && tab.title;
  } else {
    url = tab && tab.url;
    title = tab && tab.title;
  }
  if (!url || !/^https?:\/\//i.test(url)) return;

  let host = url;
  try { host = new URL(url).hostname; } catch (e) {}
  title = (title || host).slice(0, 40);

  const data = await browser.storage.local.get(["sites", "activeId"]);
  const sites = data.sites || [];
  let site = sites.find((s) => s.url === url);
  if (!site) {
    site = { id: "s" + Date.now(), url, title };
    if (folderId) site.folderId = folderId;
    sites.push(site);
  } else if (folderId !== undefined) {
    if (folderId) site.folderId = folderId;
    else delete site.folderId;
  }
  await browser.storage.local.set({ sites, activeId: site.id });
});

// --- Клік по іконці відкриває бічну панель ---
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

// --- Зняття заборони на вбудовування сайтів у фрейм (X-Frame-Options / CSP) ---
// tabIds у правилах можна лише в session-правилах; вони живуть до закриття браузера,
// а цей код виконується при кожному запуску service worker.
const DNR_HEADERS = [
  { header: "x-frame-options", operation: "remove" },
  { header: "content-security-policy", operation: "remove" },
  { header: "content-security-policy-report-only", operation: "remove" }
];
// 1–2: sub_frame із панелі (не з вкладки, або ініціатор = це розширення).
// 3: fetch() із Service Worker до збережених сайтів (Telegram Web кешує сторінку разом із заголовками —
//    без цього після перезапуску браузера сторінка віддається з кешу з X-Frame-Options).
async function updateWorkerRule() {
  const { sites = [] } = await chrome.storage.local.get("sites");
  const hosts = new Set();
  for (const s of sites) {
    try { hosts.add(new URL(s.url).hostname); } catch (e) {}
  }
  const addRules = [];
  if (hosts.size) {
    addRules.push({
      id: 3, priority: 1,
      action: { type: "modifyHeaders", responseHeaders: DNR_HEADERS },
      condition: { resourceTypes: ["xmlhttprequest", "other"], tabIds: [-1], requestDomains: Array.from(hosts) }
    });
  }
  await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [3], addRules });
}
async function setupRules() {
  await chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: [1, 2],
    addRules: [
      {
        id: 1, priority: 1,
        action: { type: "modifyHeaders", responseHeaders: DNR_HEADERS },
        condition: { resourceTypes: ["sub_frame"], tabIds: [-1] }
      },
      {
        id: 2, priority: 1,
        action: { type: "modifyHeaders", responseHeaders: DNR_HEADERS },
        condition: { resourceTypes: ["sub_frame"], initiatorDomains: [chrome.runtime.id] }
      }
    ]
  });
  await updateWorkerRule();
}
setupRules().catch((e) => console.error("setupRules failed:", e));

// --- Гаряча клавіша: відкрити / закрити бічну панель ---
function togglePanel(windowId) {
  const port = openPanels.get(windowId);
  if (port) {
    try { port.postMessage({ cmd: "close" }); } catch (e) {}
    openPanels.delete(windowId);
  } else {
    // sidePanel.open() потребує жесту користувача — виклик одразу з обробника команди
    chrome.sidePanel.open({ windowId }).catch((e) => console.error("sidePanel.open failed", e));
  }
}

chrome.commands.onCommand.addListener((cmd, tab) => {
  if (cmd === "toggle-panel") {
    if (tab && tab.windowId != null) togglePanel(tab.windowId);
    else chrome.windows.getLastFocused().then((w) => togglePanel(w.id));
  } else if (cmd === "fix-layout" || cmd === "translit") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      sendTool(cmd, tabs[0] && tabs[0].id, 0);
    });
  }
});


// ===================== Синхронізація через обліковий запис браузера (storage.sync) =====================
// Знімок (сайти, теки, нотатки без вкладень) стискається gzip → base64 і ріжеться на шматки по ~6,5 КБ
// (ліміт одного запису 8 КБ, всього ≈100 КБ). Метадані sy:meta пишуться в тому ж виклику.
// Нова віддалена версія без локальних змін — просто застосовується; якщо є і те, і те — зміни зливаються
// (нічого не видаляється). Локальні вкладення, масштаб і режим ПК не синхронізуються.
const SYNC_FIELDS = ["sites", "folders", "notesList", "noteFolders"];
const SYNC_CHUNK = 6500;
let deviceId = null;
let syncTimer = null;
let syncRunning = null;
let syncAgain = false;

async function gzipB64(str) {
  const cs = new CompressionStream("gzip");
  const w = cs.writable.getWriter();
  w.write(new TextEncoder().encode(str));
  w.close();
  const buf = new Uint8Array(await new Response(cs.readable).arrayBuffer());
  let bin = "";
  for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  return btoa(bin);
}
async function ungzipB64(b64) {
  const bin = atob(b64);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  const ds = new DecompressionStream("gzip");
  const w = ds.writable.getWriter();
  w.write(arr);
  w.close();
  return await new Response(ds.readable).text();
}

function dropBlob(id) {
  try {
    const r = indexedDB.open("my-sidebar-files", 1);
    r.onupgradeneeded = () => r.result.createObjectStore("files");
    r.onsuccess = () => {
      const db = r.result;
      const tx = db.transaction("files", "readwrite");
      tx.objectStore("files").delete(id);
      tx.oncomplete = () => db.close();
    };
  } catch (e) {}
}

// Нормалізація й перевірка знімка (і локального, і віддаленого)
function cleanSnap(o) {
  const isStr = (v) => typeof v === "string";
  const isNum = (v) => typeof v === "number" && isFinite(v);
  const out = { v: 1, sites: [], folders: [], notesList: [], noteFolders: [] };
  if (!o || typeof o !== "object") return out;
  const arr = (v) => (Array.isArray(v) ? v : []);

  const fids = new Set();
  for (const f of arr(o.folders)) {
    if (f && isStr(f.id) && isStr(f.name) && f.name.trim() && !fids.has(f.id)) {
      fids.add(f.id);
      const c = { id: f.id.slice(0, 64), name: f.name.slice(0, 30) };
      if (isStr(f.color) && /^#[0-9a-fA-F]{6}$/.test(f.color)) c.color = f.color;
      if (f.label === true) c.label = true;
      out.folders.push(c);
    }
  }
  const sids = new Set();
  for (const s of arr(o.sites)) {
    if (s && isStr(s.id) && isStr(s.url) && /^https?:\/\//i.test(s.url) && !sids.has(s.id)) {
      sids.add(s.id);
      const c = { id: s.id.slice(0, 64), url: s.url, title: (isStr(s.title) && s.title ? s.title : s.url).slice(0, 40) };
      if (isStr(s.folderId) && fids.has(s.folderId)) c.folderId = s.folderId;
      out.sites.push(c);
    }
  }
  const nfids = new Set();
  for (const f of arr(o.noteFolders)) {
    if (f && isStr(f.id) && isStr(f.name) && f.name.trim() && !nfids.has(f.id)) {
      nfids.add(f.id);
      out.noteFolders.push({ id: f.id.slice(0, 64), name: f.name.slice(0, 30), open: f.open === true });
    }
  }
  const nids = new Set();
  for (const n of arr(o.notesList)) {
    if (n && isStr(n.id) && !nids.has(n.id)) {
      nids.add(n.id);
      const c = { id: n.id.slice(0, 64), text: isStr(n.text) ? n.text : "" };
      c.created = isNum(n.created) ? n.created : 0;
      c.modified = isNum(n.modified) ? n.modified : c.created;
      if (isNum(n.trashed) && n.trashed > 0) c.trashed = n.trashed;
      if (isStr(n.folderId) && nfids.has(n.folderId)) c.folderId = n.folderId;
      if (isStr(n.url) && /^https?:\/\//i.test(n.url)) c.url = n.url.slice(0, 2000);
      out.notesList.push(c);
    }
  }
  return out;
}

async function localSnapshot() {
  const d = await browser.storage.local.get(SYNC_FIELDS);
  return cleanSnap({ sites: d.sites, folders: d.folders, notesList: d.notesList, noteFolders: d.noteFolders });
}

async function readRemote() {
  const got = await browser.storage.sync.get("sy:meta");
  const meta = got["sy:meta"];
  if (!meta || !meta.n) return null;
  const keys = [];
  for (let i = 0; i < meta.n; i++) keys.push("sy:" + i);
  const parts = await browser.storage.sync.get(keys);
  let s = "";
  for (const k of keys) {
    if (typeof parts[k] !== "string") return { meta, bad: true };
    s += parts[k];
  }
  if (s.length !== meta.len) return { meta, bad: true };
  try {
    return { meta, snap: cleanSnap(JSON.parse(await ungzipB64(s))) };
  } catch (e) {
    return { meta, bad: true };
  }
}

async function writeRemote(snap) {
  const s = await gzipB64(JSON.stringify(snap));
  const chunks = [];
  for (let i = 0; i < s.length; i += SYNC_CHUNK) chunks.push(s.slice(i, i + SYNC_CHUNK));
  const quota = browser.storage.sync.QUOTA_BYTES || 102400;
  const size = s.length + chunks.length * 12 + 150;
  if (size > quota * 0.98) {
    const err = new Error("quota");
    err.code = "quota";
    err.size = size;
    throw err;
  }
  const updatedAt = Date.now();
  const old = (await browser.storage.sync.get("sy:meta"))["sy:meta"];
  const items = {};
  chunks.forEach((c, i) => { items["sy:" + i] = c; });
  items["sy:meta"] = { v: 1, updatedAt, device: deviceId, n: chunks.length, len: s.length };
  await browser.storage.sync.set(items);
  if (old && old.n > chunks.length) {
    const stale = [];
    for (let i = chunks.length; i < old.n; i++) stale.push("sy:" + i);
    await browser.storage.sync.remove(stale);
  }
  return { updatedAt, size };
}

// Злиття двох списків тек за id, а однакові за назвою — в одну (повертає ще відображення id → id)
function mergeFolderLists(local, remote) {
  const list = remote.slice();
  const ids = new Set(list.map((f) => f.id));
  const byName = new Map(list.map((f) => [f.name.toLowerCase(), f]));
  const map = new Map();
  for (const f of local) {
    if (ids.has(f.id)) continue;
    const same = byName.get(f.name.toLowerCase());
    if (same) { map.set(f.id, same.id); continue; }
    list.push(f); ids.add(f.id); byName.set(f.name.toLowerCase(), f);
  }
  return { list, map, ids };
}

function mergeSnaps(L, R) {
  const mf = mergeFolderLists(L.folders, R.folders);
  const sites = R.sites.slice();
  const urls = new Set(sites.map((s) => s.url));
  const sids = new Set(sites.map((s) => s.id));
  for (const s of L.sites) {
    if (urls.has(s.url) || sids.has(s.id)) continue;
    const c = { ...s };
    if (c.folderId && mf.map.has(c.folderId)) c.folderId = mf.map.get(c.folderId);
    if (c.folderId && !mf.ids.has(c.folderId)) delete c.folderId;
    sites.push(c); urls.add(c.url); sids.add(c.id);
  }
  const mn = mergeFolderLists(L.noteFolders, R.noteFolders);
  const notes = R.notesList.slice();
  const idx = new Map(notes.map((n, i) => [n.id, i]));
  for (const n of L.notesList) {
    const c = { ...n };
    if (c.folderId && mn.map.has(c.folderId)) c.folderId = mn.map.get(c.folderId);
    if (c.folderId && !mn.ids.has(c.folderId)) delete c.folderId;
    if (idx.has(n.id)) {
      const i = idx.get(n.id);
      if ((c.modified || 0) > (notes[i].modified || 0)) notes[i] = c;
    } else {
      idx.set(n.id, notes.length);
      notes.push(c);
    }
  }
  return cleanSnap({ sites, folders: mf.list, notesList: notes, noteFolders: mn.list });
}

async function applySnap(snap) {
  const d = await browser.storage.local.get(["sites", "notesList", "zooms", "desk", "activeId", "activeNoteId"]);
  const byUrl = new Map((d.sites || []).map((s) => [s.url, s]));
  const zooms = { ...(d.zooms || {}) };
  const desk = { ...(d.desk || {}) };
  let activeId = d.activeId;
  // той самий сайт на іншому пристрої має інший id — переносимо його масштаб і режим ПК
  for (const s of snap.sites) {
    const o = byUrl.get(s.url);
    if (o && o.id !== s.id) {
      if (zooms[o.id] != null && zooms[s.id] == null) zooms[s.id] = zooms[o.id];
      if (desk[o.id] != null && desk[s.id] == null) desk[s.id] = desk[o.id];
      if (activeId === o.id) activeId = s.id;
    }
  }
  const ids = new Set(snap.sites.map((s) => s.id));
  for (const k of Object.keys(zooms)) if (!ids.has(k)) delete zooms[k];
  for (const k of Object.keys(desk)) if (!ids.has(k)) delete desk[k];
  if (!ids.has(activeId)) activeId = snap.sites[0] ? snap.sites[0].id : null;

  // локальні вкладення лишаються біля своїх нотаток
  const oldNotes = new Map((d.notesList || []).map((n) => [n.id, n]));
  const notes = snap.notesList.map((n) => {
    const o = oldNotes.get(n.id);
    const c = { ...n };
    if (o && o.files && o.files.length) c.files = o.files;
    return c;
  });
  const keep = new Set(notes.map((n) => n.id));
  for (const [id, o] of oldNotes) if (!keep.has(id)) (o.files || []).forEach((f) => dropBlob(f.id));
  let activeNoteId = d.activeNoteId;
  if (!keep.has(activeNoteId)) activeNoteId = notes[0] ? notes[0].id : null;

  await browser.storage.local.set({
    sites: snap.sites, folders: snap.folders, notesList: notes, noteFolders: snap.noteFolders,
    zooms, desk, activeId, activeNoteId, syncApplied: Date.now()
  });
}

function setSyncStatus(st) {
  return browser.storage.local.set({ syncStatus: { at: Date.now(), ...st } }).catch(() => {});
}

async function doSync() {
  await deviceReady;
  const st = await browser.storage.local.get(["syncEnabled", "syncBase", "syncDirty"]);
  if (!st.syncEnabled) return;
  if (!browser.storage.sync) { await setSyncStatus({ ok: false, error: "unsupported" }); return; }
  let base = st.syncBase || 0;
  let dirty = !!st.syncDirty;
  try {
    const remote = await readRemote();
    if (remote && remote.bad) {
      await setSyncStatus({ ok: false, error: "incomplete" });
      scheduleSync(30000);   // дані ще докачуються з Firefox Sync
      return;
    }
    let local = await localSnapshot();
    let size = remote ? remote.meta.len : 0;
    if (remote && remote.meta.updatedAt !== base) {
      // є нова віддалена версія
      const rj = JSON.stringify(remote.snap);
      if (!dirty && base) {
        if (JSON.stringify(local) !== rj) await applySnap(remote.snap);
        local = remote.snap;
      } else {
        const merged = mergeSnaps(local, remote.snap);
        if (JSON.stringify(local) !== JSON.stringify(merged)) await applySnap(merged);
        local = merged;
        dirty = JSON.stringify(merged) !== rj;
      }
      base = remote.meta.updatedAt;
    } else if (remote && dirty && JSON.stringify(local) === JSON.stringify(remote.snap)) {
      dirty = false;   // змінилось лише те, що не синхронізується (наприклад, вкладення)
    }
    if (dirty || !remote) {
      const w = await writeRemote(local);
      base = w.updatedAt;
      size = w.size;
      dirty = false;
    }
    await browser.storage.local.set({ syncBase: base, syncDirty: dirty });
    await setSyncStatus({ ok: true, size, quota: browser.storage.sync.QUOTA_BYTES || 102400 });
  } catch (e) {
    console.error("sync failed:", e);
    await setSyncStatus({
      ok: false,
      error: e && e.code === "quota" ? "quota" : "generic",
      detail: String((e && e.message) || e).slice(0, 120)
    });
  }
}

function syncRun() {
  if (syncRunning) { syncAgain = true; return syncRunning; }
  syncRunning = doSync().finally(() => {
    syncRunning = null;
    if (syncAgain) { syncAgain = false; scheduleSync(1000); }
  });
  return syncRunning;
}
function scheduleSync(ms) {
  clearTimeout(syncTimer);
  syncTimer = setTimeout(syncRun, ms);
}

async function clearRemote() {
  const all = await browser.storage.sync.get(null);
  const keys = Object.keys(all).filter((k) => k.startsWith("sy:"));
  if (keys.length) await browser.storage.sync.remove(keys);
  await browser.storage.local.set({ syncBase: 0, syncDirty: true });
  await setSyncStatus({ ok: true, cleared: true });
}

browser.storage.onChanged.addListener((ch, area) => {
  if (area === "sync") {
    const m = ch["sy:meta"];
    if (m && m.newValue) deviceReady.then(() => { if (m.newValue.device !== deviceId) scheduleSync(1500); });
    return;
  }
  if (area !== "local") return;
  if (ch.syncEnabled) {
    if (ch.syncEnabled.newValue) {
      browser.storage.local.set({ syncDirty: true, syncBase: 0 }).then(() => scheduleSync(300));
    } else {
      clearTimeout(syncTimer);
    }
    return;
  }
  if (ch.syncApplied) return;   // це ми самі застосували віддалену версію
  if (SYNC_FIELDS.some((k) => k in ch)) {
    browser.storage.local.set({ syncDirty: true });
    scheduleSync(8000);
  }
});

chrome.runtime.onMessage.addListener((m, sender, sendResponse) => {
  if (!m || !m.cmd) return;
  if (m.cmd === "sync-now") { syncRun().then(() => sendResponse(true), () => sendResponse(false)); return true; }
  if (m.cmd === "sync-clear") { clearRemote().then(() => sendResponse(true), () => sendResponse(false)); return true; }
});

// ID пристрою; обробники подій чекають на deviceReady
const deviceReady = (async () => {
  const d = await browser.storage.local.get("syncDevice");
  deviceId = d.syncDevice;
  if (!deviceId) {
    deviceId = Math.random().toString(36).slice(2) + Date.now().toString(36);
    await browser.storage.local.set({ syncDevice: deviceId });
  }
})();

async function syncIfEnabled(ms) {
  const d = await browser.storage.local.get("syncEnabled");
  if (d.syncEnabled) scheduleSync(ms);
}
// Service worker засинає, тому періодичну перевірку й старт робимо через alarms/події, а не setInterval
chrome.runtime.onStartup.addListener(() => syncIfEnabled(2000));
chrome.runtime.onInstalled.addListener(() => syncIfEnabled(2000));
chrome.alarms.get("my-sidebar-sync").then((a) => {
  if (!a) chrome.alarms.create("my-sidebar-sync", { periodInMinutes: 15 });
});
chrome.alarms.onAlarm.addListener((a) => { if (a.name === "my-sidebar-sync") syncIfEnabled(0); });
