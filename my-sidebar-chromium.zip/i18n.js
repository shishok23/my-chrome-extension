// Переклади інтерфейсу (укр / англ). Підключається і до панелі, і до фонового скрипта.
const I18N = {
  uk: {

    helpBtn: "Довідка",
    notesTitle: "📝 Нотатки", defaultNoteTitle: "Нотатка", noteNamePlaceholder: "Назва...", addNote: "Додати", delNote: "Видалити", notesPlaceholder: "Пишіть тут... Зберігається автоматично.",
    noteSearch: "Пошук", noteSortModified: "Сортувати за датою останньої зміни", noteSortCreated: "Сортувати за датою створення", noteSortTitle: "Сортувати за назвою",
    noteTrash: "Кошик", noteEmpty: "(порожня нотатка)", noteToTrash: "У кошик", noteDeleteForever: "Видалити назавжди", noteRestore: "Відновити",
    noteNewFolder: "Нова тека", noteFolderDefault: "Тека", noteDelFolder: "Видалити теку (нотатки лишаться)", noteMd: "Markdown-перегляд", noteExpand: "Розгорнути редактор",
    noteAddress: "Адреса", noteOpenAddr: "Відкрити адресу", noteAddrFill: "Вставити адресу поточної вкладки", noteCreated: "Створено", noteModified: "Змінено",
    noteShot: "Скриншот видимої частини вкладки", noteAttach: "Додати файл (або вставте зображення Ctrl+V)", noteShotFail: "Не вдалося зробити скриншот цієї сторінки",
    noteFileTooBig: "«{0}» більший за 10 МБ", noteFileMissing: "Файл не знайдено", noteFileSave: "Зберегти файл", noteFileDel: "Видалити вкладення",
    syncTitle: "Синхронізація (Firefox Sync)", syncEnable: "Синхронізувати сайти, теки й нотатки", syncNow: "Синхронізувати зараз", syncClear: "Видалити хмарні дані",
    syncWorking: "Синхронізація...", syncOk: "Остання синхронізація: {0}. Обсяг: {1} з {2} КБ", syncCleared: "Хмарні дані видалено",
    syncErrQuota: "Перевищено ліміт Firefox Sync (≈100 КБ). Видаліть зайві нотатки або очистіть кошик.",
    syncErrIncomplete: "Хмарні дані ще завантажуються, повторю за хвилину.", syncErrUnsupported: "Цей браузер не підтримує storage.sync.", syncErrGeneric: "Помилка синхронізації: {0}",
    syncHint: "Працює, якщо в Firefox увійдено в обліковий запис, а в about:preferences#sync увімкнено «Додатки». Вкладення, масштаб і режим ПК не синхронізуються. Якщо зміни є на обох пристроях, вони зливаються, нічого не видаляючи.",
    swTitle: "Сайт не відкривається після перезапуску?", swReset: "Скинути Service Worker активного сайту", swResetTip: "Видаляє Service Worker і його кеш для хоста активного сайту",
    swNoSite: "Спочатку виберіть сайт у панелі.", swDenied: "Дозвіл не надано.", swDone: "Готово: Service Worker для {0} скинуто, сторінку перезавантажено.", swFail: "Не вдалося: {0}",
    swHint: "Деякі сайти (наприклад, Telegram Web) кешують сторінку разом із заборонними заголовками. Скидання очищає лише Service Worker цього сайту; вхід в акаунт зазвичай лишається, але на Telegram Web може знадобитись увійти знову.",
    noteEmptyTrash: "Очистити кошик", noteEmptyTrashSure: "Видалити все?",
    helpTitle: "📖 Довідка (Мануал)",
    helpText: "<ul style='padding-left:18px;margin:0;line-height:1.6;font-size:12px;color:var(--fg);'><li><b>Додати сайт:</b> ПКМ на сторінці/посиланні → «Додати в бічну панель» або кнопка ＋ на панелі.</li><li><b>Alt+Shift+S:</b> Показати/сховати бічну панель.</li><li><b>Alt+Z:</b> Виправити розкладку (EN ⇄ UK) у активному полі вводу.</li><li><b>Alt+T:</b> Транслітерація тексту (КМУ 2010).</li><li><b>Режим ПК:</b> Змушує сайт завантажувати десктопну версію та підганяє під ширину панелі.</li><li><b>Організація:</b> Сайти та теки можна сортувати перетягуванням (Drag & Drop).</li></ul>",

    // кнопки керування
    back: "Назад", fwd: "Вперед", reload: "Перезавантажити",
    home: "На початкову сторінку сайту", addFolder: "Нова тека", addCur: "Додати поточну вкладку",
    deskLabel: "ПК",
    deskTitle: "Режим ПК: сайт у десктопній розмітці, підганяється під ширину панелі",
    zoomOut: "Зменшити масштаб цього сайту", zoomReset: "Скинути масштаб до 100%",
    zoomIn: "Збільшити масштаб цього сайту", external: "Відкрити у звичайній вкладці",
    settings: "Налаштування",
    emptyTitle: "Список порожній.",
    emptyHint: "Клацніть правою кнопкою на посилання або сторінку й виберіть «Додати в бічну панель».",
    // панель
    removeTitle: "Прибрати з панелі", noLink: "⚠ нема зв'язку", save: "Зберегти",
    renameFolder: "Перейменувати теку", deleteQ: "Видалити?",
    deleteFolderTitle: "Видалити теку (сайти залишаться на панелі)",
    folderEmpty: "Тека порожня. Перетягніть сюди іконку сайту, клацніть на ній правою кнопкою або виберіть теку в контекстному меню сторінки.",
    moveOut: "Винести з теки на панель",
    removeQ: "Прибрати «{0}» з панелі?", cancel: "Скасувати", keepSite: "Залишити сайт",
    remove: "Прибрати", removeSiteTitle: "Прибрати сайт з панелі",
    folderName: "Назва теки", folderSettings: "Налаштування теки", folderColor: "Колір теки", showLabel: "Показувати підпис на панелі", defaultColor: "За замовчуванням", customColor: "Свій колір", newFolder: "Нова тека", moveTitle: "Перемістити: {0}",
    toPanel: "На панель (без теки)", newFolderDots: "Нова тека…",
    // налаштування
    language: "Мова", exportTitle: "Експорт налаштувань", importTitle: "Імпорт налаштувань",
    exportFile: "Зберегти у файл", exportCopy: "Копіювати", copied: "Скопійовано в буфер обміну",
    importFile: "З файлу…", importPaste: "Вставити текст…",
    pasteHere: "Вставте сюди текст експорту (JSON)", importBtn: "Імпортувати",
    importBad: "Невірний файл налаштувань", back2: "Назад",
    importConfirmQ: "Імпорт: сайтів — {0}, тек — {1}. Замінити поточні налаштування?",
    replace: "Замінити", imported: "Налаштування імпортовано",
    exportNote: "Експорт містить сайти, теки, нотатки, масштаб і мову. Вкладення нотаток — лише в експорті у файл.",
    // контекстне меню
    menuLink: "Додати посилання в бічну панель",
    menuPage: "Додати цю сторінку в бічну панель",
    menuTab: "Додати вкладку в бічну панель",
    noFolder: "Без теки"
  },
  en: {

    helpBtn: "Help",
    notesTitle: "📝 Notes", defaultNoteTitle: "Note", noteNamePlaceholder: "Title...", addNote: "Add", delNote: "Delete", notesPlaceholder: "Type here... Saves automatically.",
    noteSearch: "Search", noteSortModified: "Sort by last modified", noteSortCreated: "Sort by date created", noteSortTitle: "Sort by title",
    noteTrash: "Trash", noteEmpty: "(empty note)", noteToTrash: "Move to trash", noteDeleteForever: "Delete permanently", noteRestore: "Restore",
    noteNewFolder: "New folder", noteFolderDefault: "Folder", noteDelFolder: "Delete folder (notes are kept)", noteMd: "Markdown preview", noteExpand: "Expand editor",
    noteAddress: "Address", noteOpenAddr: "Open address", noteAddrFill: "Insert address of current tab", noteCreated: "Created", noteModified: "Modified",
    noteShot: "Screenshot of the visible part of the tab", noteAttach: "Attach a file (or paste an image with Ctrl+V)", noteShotFail: "Could not capture a screenshot of this page",
    noteFileTooBig: "\"{0}\" is larger than 10 MB", noteFileMissing: "File not found", noteFileSave: "Save file", noteFileDel: "Remove attachment",
    syncTitle: "Sync (Firefox Sync)", syncEnable: "Sync sites, folders and notes", syncNow: "Sync now", syncClear: "Delete cloud data",
    syncWorking: "Syncing...", syncOk: "Last sync: {0}. Size: {1} of {2} KB", syncCleared: "Cloud data deleted",
    syncErrQuota: "Firefox Sync limit exceeded (about 100 KB). Delete some notes or empty the trash.",
    syncErrIncomplete: "Cloud data is still downloading, will retry in a minute.", syncErrUnsupported: "This browser does not support storage.sync.", syncErrGeneric: "Sync error: {0}",
    syncHint: "Works when you are signed in to Firefox and \"Add-ons\" is enabled in about:preferences#sync. Attachments, zoom and desktop mode are not synced. If both devices have changes, they are merged and nothing is deleted.",
    swTitle: "Site won't open after a restart?", swReset: "Reset Service Worker of the active site", swResetTip: "Removes the Service Worker and its cache for the active site's host",
    swNoSite: "Select a site in the panel first.", swDenied: "Permission was not granted.", swDone: "Done: Service Worker for {0} was reset and the page reloaded.", swFail: "Failed: {0}",
    swHint: "Some sites (e.g. Telegram Web) cache the page together with framing-blocking headers. Resetting clears only that site's Service Worker; you usually stay signed in, but Telegram Web may ask you to sign in again.",
    noteEmptyTrash: "Empty trash", noteEmptyTrashSure: "Delete all?",
    helpTitle: "📖 Manual",
    helpText: "<ul style='padding-left:18px;margin:0;line-height:1.6;font-size:12px;color:var(--fg);'><li><b>Add site:</b> Right-click page/link → 'Add to sidebar' or use ＋ button.</li><li><b>Alt+Shift+S:</b> Toggle sidebar.</li><li><b>Alt+Z:</b> Fix keyboard layout (EN ⇄ UK) in input.</li><li><b>Alt+T:</b> Transliterate text (CMU 2010).</li><li><b>PC Mode:</b> Fits desktop sites into the narrow sidebar.</li><li><b>Organization:</b> Drag & drop sites and folders to sort.</li></ul>",

    back: "Back", fwd: "Forward", reload: "Reload",
    home: "Go to the site's start page", addFolder: "New folder", addCur: "Add current tab",
    deskLabel: "PC",
    deskTitle: "PC mode: show the site in desktop layout, fitted to the panel width",
    zoomOut: "Zoom out this site", zoomReset: "Reset zoom to 100%",
    zoomIn: "Zoom in this site", external: "Open in a regular tab",
    settings: "Settings",
    emptyTitle: "The list is empty.",
    emptyHint: "Right-click a link or a page and choose “Add to sidebar”.",
    removeTitle: "Remove from sidebar", noLink: "⚠ no connection", save: "Save",
    renameFolder: "Rename folder", deleteQ: "Delete?",
    deleteFolderTitle: "Delete folder (sites stay on the panel)",
    folderEmpty: "The folder is empty. Drag a site icon here, right-click an icon, or choose the folder in the page's context menu.",
    moveOut: "Move out of the folder to the panel",
    removeQ: "Remove “{0}” from the sidebar?", cancel: "Cancel", keepSite: "Keep the site",
    remove: "Remove", removeSiteTitle: "Remove the site from the sidebar",
    folderName: "Folder name", folderSettings: "Folder settings", folderColor: "Folder color", showLabel: "Show label on the bar", defaultColor: "Default", customColor: "Custom color", newFolder: "New folder", moveTitle: "Move: {0}",
    toPanel: "To the panel (no folder)", newFolderDots: "New folder…",
    language: "Language", exportTitle: "Export settings", importTitle: "Import settings",
    exportFile: "Save to file", exportCopy: "Copy", copied: "Copied to clipboard",
    importFile: "From file…", importPaste: "Paste text…",
    pasteHere: "Paste the exported text (JSON) here", importBtn: "Import",
    importBad: "Invalid settings file", back2: "Back",
    importConfirmQ: "Import: {0} sites, {1} folders. Replace the current settings?",
    replace: "Replace", imported: "Settings imported",
    exportNote: "The export contains sites, folders, notes, zoom and language. Note attachments are included only in the file export.",
    menuLink: "Add link to sidebar",
    menuPage: "Add this page to sidebar",
    menuTab: "Add tab to sidebar",
    noFolder: "No folder"
  }
};

let LANG = "uk";

function t(key, ...args) {
  let s = (I18N[LANG] && I18N[LANG][key]) || I18N.uk[key] || key;
  args.forEach((a, i) => { s = s.replace("{" + i + "}", a); });
  return s;
}

function defaultLang() {
  try {
    return (browser.i18n.getUILanguage() || "").toLowerCase().startsWith("uk") ? "uk" : "en";
  } catch (e) {
    return "uk";
  }
}

async function loadLang() {
  const d = await browser.storage.local.get("lang");
  LANG = d.lang === "en" || d.lang === "uk" ? d.lang : defaultLang();
}
