// Шар сумісності: код розширення написано під Firefox (browser.*, browser.menus).
// У Chromium MV3 усі потрібні API у chrome.* вже повертають проміси, лишається лише menus → contextMenus.
(() => {
  const g = typeof self !== "undefined" ? self : window;
  if (typeof g.browser !== "undefined") return;
  g.browser = new Proxy(chrome, {
    get(target, prop) {
      if (prop === "menus") return target.contextMenus;
      return target[prop];
    }
  });
})();
