const bar = document.getElementById("bar");
const view = document.getElementById("view");
const emptyBox = document.getElementById("empty");
const rail = document.getElementById("rail");
const zoomLabel = document.getElementById("zoomval");
const shield = document.getElementById("shield");
const dropwrap = document.getElementById("dropwrap");
const drop = document.getElementById("drop");

const frames = new Map();
let sites = [];
let folders = [];
let notesList = [];
let activeNoteId = null;        // теки: [{ id, name, color?, label? }]; сайт у теці має поле folderId
let dropState = null;    // що показано у випадаючому списку
let confirmDel = false;
let activeId = null;
let zooms = {};          // масштаб кожного сайту: { id: 1.25 }
let baseDpr = window.devicePixelRatio || 1;   // devicePixelRatio при масштабі 100%
let lastNative = 1;      // попередній масштаб самої панелі (Firefox)

let desk = {};          // режим ПК: { id: ширина_у_px }
const WIDTHS = [900, 1024, 1280, 1440, 1600, 1920];
const deskBtn = document.getElementById("desk");
const STEPS = [0.3, 0.5, 0.67, 0.8, 0.9, 1, 1.1, 1.2, 1.33, 1.5, 1.7, 2, 2.4, 3, 4, 5];
const clamp = (v) => Math.min(5, Math.max(0.25, Math.round(v * 100) / 100));

function nativeZoom() {
  return (window.devicePixelRatio || 1) / baseDpr;
}

// Масштаб панелі (Firefox) гасимо на смужці й на кожному фреймі,
// а потім застосовуємо власний масштаб сайту.
function applyZoom() {
  const nz = nativeZoom();
  rail.style.zoom = String(1 / nz);
  document.getElementById("rail-controls").style.zoom = String(1 / nz);
  drop.style.zoom = String(1 / nz);
  positionDrop();
  const cw = view.clientWidth, ch = view.clientHeight;
  for (const [id, f] of frames) {
    if (desk[id]) {
      if (!cw) continue;
      const W = desk[id];
      const k = cw / W;
      f.style.transform = "scale(" + k + ")";
      f.style.width = W + "px";
      f.style.height = ch / k + "px";
    } else {
      const k = (zooms[id] || 1) / nz;
      f.style.transform = "scale(" + k + ")";
      f.style.width = 100 / k + "%";
      f.style.height = 100 / k + "%";
    }
  }
  deskBtn.classList.toggle("on", !!desk[activeId]);
  zoomLabel.textContent = desk[activeId]
    ? desk[activeId] + "px"
    : Math.round((zooms[activeId] || 1) * 100) + "%";
}

function setSiteZoom(id, value) {
  if (!id) return;
  zooms[id] = clamp(value);
  browser.storage.local.set({ zooms });
  applyZoom();
}

// Користувач масштабує панель (Ctrl+колесо, Ctrl+/−): переносимо зміну на активний сайт
function onNativeChange() {
  const nz = nativeZoom();
  const ratio = nz / lastNative;
  lastNative = nz;
  if (Math.abs(ratio - 1) > 0.005 && activeId && !desk[activeId]) {
    zooms[activeId] = clamp((zooms[activeId] || 1) * ratio);
    browser.storage.local.set({ zooms });
  }
  applyZoom();
}
window.addEventListener("resize", onNativeChange);

function stepZoom(dir) {
  if (desk[activeId]) {
    const i = WIDTHS.indexOf(desk[activeId]);
    const j = Math.min(WIDTHS.length - 1, Math.max(0, i - dir));
    desk[activeId] = WIDTHS[j];
    browser.storage.local.set({ desk });
    applyZoom();
    return;
  }
  const cur = zooms[activeId] || 1;
  let next = cur;
  if (dir > 0) next = STEPS.find((s) => s > cur + 0.005) || STEPS[STEPS.length - 1];
  else next = [...STEPS].reverse().find((s) => s < cur - 0.005) || STEPS[0];
  setSiteZoom(activeId, next);
}

document.getElementById("zoomin").onclick = () => stepZoom(1);
document.getElementById("zoomout").onclick = () => stepZoom(-1);
zoomLabel.onclick = () => {
  if (desk[activeId]) {
    desk[activeId] = 1280;
    browser.storage.local.set({ desk });
    applyZoom();
  } else {
    setSiteZoom(activeId, 1);
  }
};

deskBtn.onclick = () => {
  if (!activeId) return;
  if (desk[activeId]) delete desk[activeId];
  else desk[activeId] = 1280;
  browser.storage.local.set({ desk });
  applyZoom();
};

new ResizeObserver(() => applyZoom()).observe(view);

async function readSites() {
  if (noteSaveTimer) await flushNotes();   // не губимо ще не збережений текст нотатки
  const d = await browser.storage.local.get(["sites", "activeId", "folders", "notes", "notesList", "activeNoteId", "noteFolders", "notesSort", "syncEnabled", "syncStatus"]);
  syncEnabled = !!d.syncEnabled;
  syncStatus = d.syncStatus || null;
  notesList = Array.isArray(d.notesList) ? d.notesList : [{ id: "n1", text: d.notes || "" }];
  if (migrateNotes(notesList) || !d.notesList) persistNotes(true);
  noteFolders = Array.isArray(d.noteFolders) ? d.noteFolders : [];
  if (["modified", "created", "title"].includes(d.notesSort)) notesSort = d.notesSort;
  activeNoteId = d.activeNoteId || (notesList[0] && notesList[0].id) || null;
  if (!notesList.find(n => n.id === activeNoteId)) activeNoteId = notesList[0] ? notesList[0].id : null;
  folders = d.folders || [];
  sites = d.sites || [];
  activeId = d.activeId;
  if (!sites.some((s) => s.id === activeId)) activeId = sites[0] ? sites[0].id : null;
}

function render() {
  bar.textContent = "";
  const topLevel = (s) => !s.folderId || !folders.some((f) => f.id === s.folderId);

  for (const s of sites.filter(topLevel)) {
    const b = document.createElement("button");
    b.className = "site" + (s.id === activeId ? " active" : "");
    b.title = s.title + "\n" + s.url;

    const x = document.createElement("span");
    x.className = "x";
    x.textContent = "×";
    x.title = t("removeTitle");
    x.onclick = (e) => { e.stopPropagation(); openDrop({ type: "remove", siteId: s.id, from: dropState }); };

    b.append(makeIcon(s), x);
    b.onclick = () => { closeDrop(); browser.storage.local.set({ activeId: s.id }); };
    makeSortable(b, "site", s.id, false);
    b.oncontextmenu = (e) => { e.preventDefault(); openDrop({ type: "move", siteId: s.id }); };
    bar.append(b);
  }

  for (const f of folders) {
    const b = document.createElement("button");
    const inside = sites.some((s) => s.id === activeId && s.folderId === f.id);
    const isOpen = dropState && dropState.type === "folder" && dropState.id === f.id;
    b.className = "site folder" + (inside ? " active" : "") + (isOpen ? " open" : "");
    const n = sites.filter((s) => s.folderId === f.id).length;
    b.title = f.name + " (" + n + ")";
    b.append(folderIcon(f.color));
    if (f.label) {
      b.classList.add("labeled");
      const l = document.createElement("span");
      l.className = "flabel";
      l.textContent = f.name;
      b.append(l);
    }
    b.onclick = () => toggleDrop({ type: "folder", id: f.id });
    makeSortable(b, "folder", f.id, false);
    const sortOver = b.ondragover, sortDrop = b.ondrop;
    b.ondragover = (e) => {
      if (dragging && dragging.kind === "site") { e.preventDefault(); return; } // сайт → у теку
      sortOver(e);
    };
    b.ondrop = (e) => {
      if (dragging && dragging.kind === "site") {
        e.preventDefault();
        const sid = dragging.id;
        dragging = null;
        clearMarks();
        moveSite(sid, f.id);
        return;
      }
      sortDrop(e);
    };
    bar.append(b);
  }

  addFolderBtn.classList.toggle("on", !!(dropState && dropState.type === "new"));
  notesBtn.classList.toggle("on", !!(dropState && dropState.type === "notes"));
  helpBtn.classList.toggle("on", !!(dropState && dropState.type === "help"));
  settingsBtn.classList.toggle("on", !!(dropState && /^(settings|export-text|import-paste|import-confirm)$/.test(dropState.type)));

  for (const [id, f] of frames) {
    if (!sites.some((s) => s.id === id)) { f.remove(); frames.delete(id); }
  }
  if (activeId && !frames.has(activeId)) {
    const s = sites.find((x) => x.id === activeId);
    const f = document.createElement("iframe");
    f.src = s.url;
    view.append(f);
    frames.set(activeId, f);
  }
  for (const [id, f] of frames) f.style.display = id === activeId ? "block" : "none";
  emptyBox.hidden = sites.length > 0;

  const cur = sites.find((x) => x.id === activeId);
  try {
    document.title = cur ? "My Sidebar · " + cur.title : "My Sidebar";
  } catch (e) {}
  applyZoom();
  if (dropState) buildDrop();
}

async function removeSite(id) {
  delete zooms[id];
  delete desk[id];
  await browser.storage.local.set({ sites: sites.filter((s) => s.id !== id), zooms, desk });
}

// --- Навігація всередині сайту (через скрипт у фреймі) ---
function sendCmd(cmd) {
  const f = frames.get(activeId);
  if (!f || !f.contentWindow) return Promise.resolve(null);
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      window.removeEventListener("message", onReply);
      resolve(null);
    }, 700);
    function onReply(e) {
      const d = e.data;
      if (e.source === f.contentWindow && d && d.__sis === 1 && d.cmd === cmd && d.ack) {
        clearTimeout(timer);
        window.removeEventListener("message", onReply);
        resolve(d);
      }
    }
    window.addEventListener("message", onReply);
    f.contentWindow.postMessage({ __sis: 1, cmd }, "*");
  });
}

function flashNoLink() {
  const old = zoomLabel.textContent;
  zoomLabel.textContent = t("noLink");
  setTimeout(() => applyZoom(), 1500);
}

document.getElementById("back").onclick = async () => {
  if (!(await sendCmd("back"))) flashNoLink();
};
document.getElementById("fwd").onclick = async () => {
  if (!(await sendCmd("forward"))) flashNoLink();
};
document.getElementById("home").onclick = () => {
  const f = frames.get(activeId);
  const s = sites.find((x) => x.id === activeId);
  if (f && s) f.src = s.url;
};
document.getElementById("reload").onclick = async () => {
  if (await sendCmd("reload")) return;
  const f = frames.get(activeId);
  const s = sites.find((x) => x.id === activeId);
  if (f && s) f.src = s.url;
};
document.getElementById("external").onclick = async () => {
  const s = sites.find((x) => x.id === activeId);
  if (!s) return;
  const r = await sendCmd("where");
  browser.tabs.create({ url: (r && r.href) || s.url });
};

browser.storage.onChanged.addListener(async (ch, area) => {
  if (area && area !== "local") return;
  if (ch.syncApplied) {
    // фон застосував версію з Firefox Sync: відкидаємо ще не збережений локальний текст (≤0,3 с набору),
    // інакше він перезаписав би щойно отримані нотатки, і перечитуємо все
    if (noteSaveTimer) { clearTimeout(noteSaveTimer); noteSaveTimer = null; }
    const z = await browser.storage.local.get(["zooms", "desk"]);
    zooms = z.zooms || {};
    desk = z.desk || {};
    await readSites();
    render();
    applyZoom();
    return;
  }
  if (ch.lang && ch.lang.newValue && ch.lang.newValue !== LANG) {
    LANG = ch.lang.newValue;
    applyI18n();
    render();
  }
  if (ch.syncEnabled || ch.syncStatus) {
    if (ch.syncEnabled) syncEnabled = !!ch.syncEnabled.newValue;
    if (ch.syncStatus) syncStatus = ch.syncStatus.newValue || null;
    if (dropState && dropState.type === "settings") render();
  }
  if (ch.sites || ch.activeId || ch.folders) {
    await readSites();
    render();
  }
});


// ===================== Теки та випадаючий список =====================
function makeIcon(s) {
  let domain = "";
  try { domain = new URL(s.url).hostname; } catch (e) {}
  const icon = document.createElement("img");
  icon.src = `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;
  icon.onerror = () => {
    const l = document.createElement("span");
    l.className = "letter";
    l.textContent = (s.title[0] || "?").toUpperCase();
    icon.replaceWith(l);
  };
  return icon;
}

function svgEl(paths) {
  const NS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(NS, "svg");
  svg.setAttribute("viewBox", "0 0 24 24");
  for (const p of paths) {
    const el = document.createElementNS(NS, "path");
    for (const [k, v] of Object.entries(p)) el.setAttribute(k, v);
    svg.append(el);
  }
  return svg;
}
const FOLDER_D = "M3 6.5A1.5 1.5 0 0 1 4.5 5h4.6l2 2.2h8.4A1.5 1.5 0 0 1 21 8.7v9.8a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 18.5z";
const folderIcon = (color) => svgEl([{ d: FOLDER_D, fill: color || "#e8a838" }]);
const folderPlusIcon = () => svgEl([
  { d: FOLDER_D, fill: "none", stroke: "currentColor", "stroke-width": "1.6" },
  { d: "M12 10.5v6M9 13.5h6", fill: "none", stroke: "currentColor", "stroke-width": "1.6", "stroke-linecap": "round" }
]);

function save() {
  return browser.storage.local.set({ sites, folders });
}

function moveSite(id, folderId) {
  const s = sites.find((x) => x.id === id);
  if (!s) return;
  if (folderId) s.folderId = folderId;
  else delete s.folderId;
  save();
}


// ===== Сортування перетягуванням =====
let dragging = null; // { kind: "site" | "folder", id }

function clearMarks() {
  document.querySelectorAll(".drop-before, .drop-after").forEach((el) => el.classList.remove("drop-before", "drop-after"));
}

function reorderSite(dragId, targetId, after) {
  if (dragId === targetId) return;
  const s = sites.find((x) => x.id === dragId);
  const tg = sites.find((x) => x.id === targetId);
  if (!s || !tg) return;
  sites = sites.filter((x) => x !== s);
  if (tg.folderId && folders.some((f) => f.id === tg.folderId)) s.folderId = tg.folderId;
  else delete s.folderId;
  const i = sites.indexOf(tg);
  sites.splice(after ? i + 1 : i, 0, s);
  save();
}

function reorderFolder(dragId, targetId, after) {
  if (dragId === targetId) return;
  const f = folders.find((x) => x.id === dragId);
  const tg = folders.find((x) => x.id === targetId);
  if (!f || !tg) return;
  folders = folders.filter((x) => x !== f);
  const i = folders.indexOf(tg);
  folders.splice(after ? i + 1 : i, 0, f);
  save();
}

// Робить елемент перетягуваним і придатним для вставки «до/після» себе.
// vertical: true для рядків списку, false для кнопок на панелі.
function makeSortable(el, kind, id, vertical) {
  const isAfter = (e) => {
    const r = el.getBoundingClientRect();
    return vertical ? e.clientY > r.top + r.height / 2 : e.clientX > r.left + r.width / 2;
  };
  el.draggable = true;
  el.ondragstart = (e) => {
    dragging = { kind, id };
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/plain", id);
  };
  el.ondragend = () => { dragging = null; clearMarks(); };
  el.ondragover = (e) => {
    if (!dragging || dragging.kind !== kind || dragging.id === id) return;
    e.preventDefault();
    clearMarks();
    el.classList.add(isAfter(e) ? "drop-after" : "drop-before");
  };
  el.ondragleave = () => el.classList.remove("drop-before", "drop-after");
  el.ondrop = (e) => {
    if (!dragging || dragging.kind !== kind || dragging.id === id) return;
    e.preventDefault();
    e.stopPropagation();
    const d = dragging, after = isAfter(e);
    dragging = null;
    clearMarks();
    if (kind === "site") reorderSite(d.id, id, after);
    else reorderFolder(d.id, id, after);
  };
}

function deleteFolder(id) {
  for (const s of sites) if (s.folderId === id) delete s.folderId;
  folders = folders.filter((f) => f.id !== id);
  closeDrop();
  save();
}

function positionDrop() {
  if (dropwrap.hidden) return;
  const top = Math.round(rail.getBoundingClientRect().bottom);
  dropwrap.style.top = top + "px";
  shield.style.top = top + "px";
  if (dropState && dropState.type === "notes") {
    drop.style.height = Math.max(240, Math.round((window.innerHeight - top - 8) * nativeZoom())) + "px";
  }
}

function openDrop(state) {
  dropState = state;
  confirmDel = false;
  shield.hidden = false;
  dropwrap.hidden = false;
  positionDrop();
  render();
}

function closeDrop() {
  if (!dropState && dropwrap.hidden) return;
  dropState = null;
  confirmDel = false;
  shield.hidden = true;
  dropwrap.hidden = true;
  render();
}

function toggleDrop(state) {
  const same = dropState && dropState.type === state.type && dropState.id === state.id;
  if (same) closeDrop();
  else openDrop(state);
}

shield.onclick = closeDrop;
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closeDrop();
});

// Безпечне вставлення HTML без innerHTML: розбір через DOMParser (скрипти не виконуються),
// у розмітці лише наші власні, вже екрановані рядки (довідка, markdown-перегляд).
function setHtml(el, html) {
  const doc = new DOMParser().parseFromString(String(html), "text/html");
  el.replaceChildren(...Array.from(doc.body.childNodes));
}

// Скидає Service Worker (і його кеш) хоста активного сайту. Потрібен дозвіл browsingData — запитуємо за кліком.
async function resetSiteWorker(msgEl) {
  const say = (txt, err) => { msgEl.hidden = false; msgEl.textContent = txt; msgEl.classList.toggle("err", !!err); };
  const cur = sites.find((x) => x.id === activeId);
  if (!cur) { say(t("swNoSite"), true); return; }
  let host;
  try { host = new URL(cur.url).hostname; } catch (e) { say(t("swNoSite"), true); return; }
  try {
    // permissions.request має викликатись одразу з кліку, до будь-яких await
    const ok = await browser.permissions.request({ permissions: ["browsingData"] });
    if (!ok) { say(t("swDenied"), true); return; }
    if (typeof chrome !== "undefined" && chrome.sidePanel) {
      // Chromium: фільтр за origin, окремо кеш Service Worker (Cache Storage)
      await browser.browsingData.remove({ origins: [new URL(cur.url).origin] }, { serviceWorkers: true, cacheStorage: true });
    } else {
      await browser.browsingData.remove({ hostnames: [host] }, { serviceWorkers: true });
    }
    const f = frames.get(cur.id);
    if (f) f.src = cur.url;
    say(t("swDone", host));
  } catch (e) {
    say(t("swFail", String((e && e.message) || e).slice(0, 100)), true);
  }
}

function buildDrop() {
  drop.textContent = "";
  drop.classList.remove("notes");
  drop.style.height = "";
  drop.style.zoom = String(1 / nativeZoom());
  const st = dropState;
  if (!st) return;

  const mkBtn = (txt, title, fn) => {
    const b = document.createElement("button");
    b.className = "dbtn";
    b.textContent = txt;
    b.title = title;
    b.onclick = (e) => { e.stopPropagation(); fn(); };
    return b;
  };
  const head = (text, ...btns) => {
    const h = document.createElement("div");
    h.className = "dhead";
    const n = document.createElement("span");
    n.className = "dname";
    n.textContent = text;
    h.append(n, ...btns);
    drop.append(h);
  };
  const form = (placeholder, initial, onSubmit) => {
    const w = document.createElement("div");
    w.className = "dform";
    const inp = document.createElement("input");
    inp.type = "text";
    inp.placeholder = placeholder;
    inp.value = initial || "";
    inp.maxLength = 30;
    const go = () => { const v = inp.value.trim(); if (v) onSubmit(v); };
    inp.onkeydown = (e) => { if (e.key === "Enter") go(); };
    w.append(inp, mkBtn("OK", t("save"), go));
    drop.append(w);
    setTimeout(() => { inp.focus(); inp.select(); }, 0);
  };
  const row = (iconNode, text, onClick, active, ...btns) => {
    const r = document.createElement("div");
    r.className = "ditem" + (active ? " active" : "");
    const t = document.createElement("span");
    t.className = "t";
    t.textContent = text;
    r.append(iconNode, t, ...btns);
    r.onclick = onClick;
    drop.append(r);
    return r;
  };

  if (st.type === "folder") {
    const f = folders.find((x) => x.id === st.id);
    if (!f) { closeDrop(); return; }
    head(
      f.name,
      mkBtn("✎", t("folderSettings"), () => openDrop({ type: "rename", id: f.id })),
      mkBtn(confirmDel ? t("deleteQ") : "🗑", t("deleteFolderTitle"), () => {
        if (!confirmDel) {
          confirmDel = true;
          buildDrop();
          setTimeout(() => {
            if (confirmDel && dropState === st) { confirmDel = false; buildDrop(); }
          }, 3000);
          return;
        }
        deleteFolder(f.id);
      })
    );
    const list = sites.filter((s) => s.folderId === f.id);
    if (!list.length) {
      const e = document.createElement("div");
      e.className = "dempty";
      e.textContent = t("folderEmpty");
      drop.append(e);
    }
    for (const s of list) {
      const rr = row(
        makeIcon(s), s.title,
        () => { browser.storage.local.set({ activeId: s.id }); closeDrop(); },
        s.id === activeId,
        mkBtn("↑", t("moveOut"), () => moveSite(s.id, null)),
        mkBtn("×", t("removeTitle"), () => openDrop({ type: "remove", siteId: s.id, from: st }))
      );
      makeSortable(rr, "site", s.id, true);
    }
  } else if (st.type === "remove") {
    const s = sites.find((x) => x.id === st.siteId);
    if (!s) { closeDrop(); return; }
    head(t("removeQ", s.title));
    const w = document.createElement("div");
    w.className = "dform";
    const cancel = mkBtn(t("cancel"), t("keepSite"), () => {
      if (st.from) openDrop(st.from);
      else closeDrop();
    });
    const yes = mkBtn(t("remove"), t("removeSiteTitle"), () => {
      closeDrop();
      removeSite(s.id);
    });
    yes.classList.add("danger");
    w.append(cancel, yes);
    drop.append(w);
    setTimeout(() => cancel.focus(), 0);
  } else if (st.type === "settings") {
    head(t("settings"));
    const sec = (k) => {
      const d = document.createElement("div");
      d.className = "dsec";
      d.textContent = t(k);
      drop.append(d);
    };
    const btnRow = (...btns) => {
      const w = document.createElement("div");
      w.className = "dform";
      w.append(...btns);
      drop.append(w);
    };
    const langBtn = (code, name) => {
      const b = mkBtn(name, name, () => setLang(code));
      if (LANG === code) b.classList.add("sel");
      return b;
    };
    sec("language");
    btnRow(langBtn("uk", "Українська"), langBtn("en", "English"));
    sec("exportTitle");
    btnRow(
      mkBtn(t("exportFile"), t("exportFile"), exportToFile),
      mkBtn(t("exportCopy"), t("exportCopy"), exportToClipboard)
    );
    sec("importTitle");
    btnRow(
      mkBtn(t("importFile"), t("importFile"), importFromFile),
      mkBtn(t("importPaste"), t("importPaste"), () => openDrop({ type: "import-paste" }))
    );
    const note = document.createElement("div");
    note.className = "dmsg";
    note.style.opacity = ".6";
    note.textContent = t("exportNote");
    drop.append(note);

    // --- Скидання Service Worker активного сайту ---
    sec("swTitle");
    const swMsg = document.createElement("div");
    swMsg.className = "dmsg";
    swMsg.hidden = true;
    btnRow(mkBtn(t("swReset"), t("swResetTip"), () => resetSiteWorker(swMsg)));
    drop.append(swMsg);
    const swHint = document.createElement("div");
    swHint.className = "dmsg";
    swHint.style.opacity = ".6";
    swHint.textContent = t("swHint");
    drop.append(swHint);

    // --- Синхронізація через Firefox Sync ---
    sec("syncTitle");
    const lab = document.createElement("label");
    lab.className = "dcheck";
    const chk = document.createElement("input");
    chk.type = "checkbox";
    chk.checked = syncEnabled;
    chk.onchange = () => { browser.storage.local.set({ syncEnabled: chk.checked }); };
    const lt = document.createElement("span");
    lt.textContent = t("syncEnable");
    lab.append(chk, lt);
    drop.append(lab);
    if (syncEnabled) {
      const sm = document.createElement("div");
      sm.className = "dmsg";
      if (!syncStatus) {
        sm.textContent = t("syncWorking");
      } else if (syncStatus.ok) {
        sm.textContent = syncStatus.cleared ? t("syncCleared") : t("syncOk", fmtDate(syncStatus.at),
          Math.round((syncStatus.size || 0) / 1024), Math.round((syncStatus.quota || 102400) / 1024));
      } else {
        sm.classList.add("err");
        sm.textContent = syncStatus.error === "quota" ? t("syncErrQuota")
          : syncStatus.error === "incomplete" ? t("syncErrIncomplete")
          : syncStatus.error === "unsupported" ? t("syncErrUnsupported")
          : t("syncErrGeneric", syncStatus.detail || "");
      }
      drop.append(sm);
      btnRow(
        mkBtn(t("syncNow"), t("syncNow"), () => { browser.runtime.sendMessage({ cmd: "sync-now" }).catch(() => {}); }),
        mkBtn(t("syncClear"), t("syncClear"), () => { browser.runtime.sendMessage({ cmd: "sync-clear" }).catch(() => {}); })
      );
    }
    const hint = document.createElement("div");
    hint.className = "dmsg";
    hint.style.opacity = ".6";
    hint.textContent = t("syncHint");
    drop.append(hint);
    if (st.msg) {
      const m = document.createElement("div");
      m.className = "dmsg" + (st.err ? " err" : "");
      m.textContent = st.msg;
      drop.append(m);
    }
  } else if (st.type === "export-text") {
    head(t("exportTitle"));
    const w = document.createElement("div");
    w.className = "dform";
    const ta = document.createElement("textarea");
    ta.readOnly = true;
    ta.value = st.text;
    w.append(ta);
    drop.append(w);
    const w2 = document.createElement("div");
    w2.className = "dform";
    w2.append(mkBtn(t("back2"), t("back2"), () => openDrop({ type: "settings" })));
    drop.append(w2);
    setTimeout(() => { ta.focus(); ta.select(); }, 0);
  } else if (st.type === "import-paste") {
    head(t("importPaste"));
    const w = document.createElement("div");
    w.className = "dform";
    const ta = document.createElement("textarea");
    ta.placeholder = t("pasteHere");
    w.append(ta);
    drop.append(w);
    const w2 = document.createElement("div");
    w2.className = "dform";
    w2.append(
      mkBtn(t("back2"), t("back2"), () => openDrop({ type: "settings" })),
      mkBtn(t("importBtn"), t("importBtn"), () => handleImportText(ta.value))
    );
    drop.append(w2);
    setTimeout(() => ta.focus(), 0);
  } else if (st.type === "import-confirm") {
    head(t("importConfirmQ", st.data.sites.length, st.data.folders.length));
    const w = document.createElement("div");
    w.className = "dform";
    const cancel = mkBtn(t("cancel"), t("cancel"), () => openDrop({ type: "settings" }));
    const yes = mkBtn(t("replace"), t("replace"), () => applyImport(st.data));
    yes.classList.add("danger");
    w.append(cancel, yes);
    drop.append(w);
    setTimeout(() => cancel.focus(), 0);
  } else if (st.type === "rename") {
    const f = folders.find((x) => x.id === st.id);
    if (!f) { closeDrop(); return; }
    head(t("folderSettings"));
    const draft = { color: f.color || "", label: !!f.label };

    // назва
    const nw = document.createElement("div");
    nw.className = "dform";
    const nameInp = document.createElement("input");
    nameInp.type = "text";
    nameInp.placeholder = t("folderName");
    nameInp.value = f.name;
    nameInp.maxLength = 30;
    nw.append(nameInp);
    drop.append(nw);

    // колір
    const cap = document.createElement("div");
    cap.className = "dcap";
    cap.textContent = t("folderColor");
    drop.append(cap);
    const sw = document.createElement("div");
    sw.className = "swatches";
    const PRESETS = ["", "#ef4444", "#ec4899", "#a855f7", "#3b82f6", "#14b8a6", "#22c55e", "#9ca3af"];
    const swBtns = [];
    const markSel = () => {
      for (const b of swBtns) b.classList.toggle("sel", b.dataset.c === draft.color);
      custom.classList.toggle("sel", !!draft.color && !PRESETS.includes(draft.color));
    };
    for (const c of PRESETS) {
      const b = document.createElement("button");
      b.className = "swatch";
      b.dataset.c = c;
      b.style.background = c || "#e8a838";
      b.title = c ? c : t("defaultColor");
      b.onclick = (e) => { e.stopPropagation(); draft.color = c; markSel(); };
      swBtns.push(b);
      sw.append(b);
    }
    const custom = document.createElement("input");
    custom.type = "color";
    custom.className = "swatch-custom";
    custom.title = t("customColor");
    custom.value = /^#[0-9a-f]{6}$/i.test(draft.color) ? draft.color : "#e8a838";
    custom.oninput = () => { draft.color = custom.value; markSel(); };
    sw.append(custom);
    drop.append(sw);
    markSel();

    // підпис на панелі (за бажанням)
    const lw = document.createElement("label");
    lw.className = "dcheck";
    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.checked = draft.label;
    cb.onchange = () => { draft.label = cb.checked; };
    const lt = document.createElement("span");
    lt.textContent = t("showLabel");
    lw.append(cb, lt);
    drop.append(lw);

    // кнопки
    const go = () => {
      const v = nameInp.value.trim();
      if (!v) { nameInp.focus(); return; }
      f.name = v;
      if (draft.color) f.color = draft.color; else delete f.color;
      if (draft.label) f.label = true; else delete f.label;
      save();
      openDrop({ type: "folder", id: f.id });
    };
    nameInp.onkeydown = (e) => { if (e.key === "Enter") go(); };
    const bw = document.createElement("div");
    bw.className = "dform";
    bw.append(
      mkBtn(t("cancel"), t("cancel"), () => openDrop({ type: "folder", id: f.id })),
      mkBtn(t("save"), t("save"), go)
    );
    drop.append(bw);
    setTimeout(() => { nameInp.focus(); nameInp.select(); }, 0);
  } else if (st.type === "notes") {
    buildNotesPanel();
  } else if (st.type === "help") {
    head(t("helpTitle"));
    const w = document.createElement("div");
    w.style.padding = "4px 8px 12px 8px";
    w.style.userSelect = "text";
    setHtml(w, t("helpText"));
    drop.append(w);
  } else if (st.type === "new") {
    head(t("newFolder"));
    form(t("folderName"), "", (v) => {
      const nf = { id: "f" + Date.now(), name: v };
      folders.push(nf);
      if (st.siteId) {
        const s = sites.find((x) => x.id === st.siteId);
        if (s) s.folderId = nf.id;
      }
      save();
      openDrop({ type: "folder", id: nf.id });
    });
  } else if (st.type === "move") {
    const s = sites.find((x) => x.id === st.siteId);
    if (!s) { closeDrop(); return; }
    head(t("moveTitle", s.title));
    for (const f of folders) {
      row(folderIcon(f.color), f.name, () => { moveSite(s.id, f.id); closeDrop(); }, s.folderId === f.id);
    }
    if (s.folderId) {
      row(svgEl([{ d: "M5 12h14M12 5l-7 7 7 7", fill: "none", stroke: "currentColor", "stroke-width": "2" }]),
        t("toPanel"), () => { moveSite(s.id, null); closeDrop(); });
    }
    row(folderPlusIcon(), t("newFolderDots"), () => openDrop({ type: "new", siteId: s.id }));
  }
}

// Додати поточну вкладку без контекстного меню (запасний шлях, напр. для Brave)
document.getElementById("addcur").onclick = async () => {
  const [tab] = await browser.tabs.query({ active: true, lastFocusedWindow: true });
  const url = tab && tab.url;
  if (!url || !/^https?:\/\//i.test(url)) return;
  let host = url;
  try { host = new URL(url).hostname; } catch (e) {}
  const data = await browser.storage.local.get(["sites", "activeId"]);
  const list = data.sites || [];
  let site = list.find((x) => x.url === url);
  if (!site) {
    site = { id: "s" + Date.now(), url, title: ((tab.title || host) + "").slice(0, 40) };
    list.push(site);
  }
  await browser.storage.local.set({ sites: list, activeId: site.id });
};

const addFolderBtn = document.getElementById("addfolder");
addFolderBtn.append(folderPlusIcon());
addFolderBtn.onclick = () => toggleDrop({ type: "new" });


// ===================== Мова, експорт та імпорт =====================
const notesBtn = document.getElementById("notesBtn");
notesBtn.onclick = () => toggleDrop({ type: "notes" });
const helpBtn = document.getElementById("helpBtn");
helpBtn.onclick = () => toggleDrop({ type: "help" });
const settingsBtn = document.getElementById("settings");
settingsBtn.onclick = () => toggleDrop({ type: "settings" });

function applyI18n() {
  document.documentElement.lang = LANG;
  for (const el of document.querySelectorAll("[data-i18n]")) el.textContent = t(el.dataset.i18n);
  for (const el of document.querySelectorAll("[data-i18n-title]")) el.title = t(el.dataset.i18nTitle);
}

function setLang(code) {
  LANG = code;
  browser.storage.local.set({ lang: code });
  applyI18n();
  render();
}

async function exportJson(withFiles) {
  const nl = [];
  for (const n of notesList) {
    const c = { ...n };
    if (n.files && n.files.length) {
      if (withFiles) {
        c.files = [];
        for (const f of n.files) {
          try {
            const b = await fileGet(f.id);
            if (b) c.files.push({ ...f, data: await blobToDataUrl(b) });
          } catch (e) {}
        }
        if (!c.files.length) delete c.files;
      } else {
        delete c.files;
      }
    }
    nl.push(c);
  }
  return JSON.stringify(
    { app: "my-sidebar", version: 2, lang: LANG, sites, folders, zooms, desk, activeId, notesList: nl, noteFolders, notesSort, activeNoteId },
    null, 2
  );
}

async function exportToFile() {
  const blob = new Blob([await exportJson(true)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "my-sidebar-settings.json";
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

async function exportToClipboard() {
  const json = await exportJson(false);
  try {
    await navigator.clipboard.writeText(json);
    openDrop({ type: "settings", msg: t("copied") });
  } catch (e) {
    // якщо буфер обміну недоступний, показуємо текст для ручного копіювання
    openDrop({ type: "export-text", text: json });
  }
}

function importFromFile() {
  const inp = document.createElement("input");
  inp.type = "file";
  inp.accept = ".json,application/json";
  inp.style.display = "none";
  inp.onchange = async () => {
    const f = inp.files[0];
    inp.remove();
    if (f) handleImportText(await f.text());
  };
  document.body.append(inp);
  inp.click();
}

// Залишаємо тільки очікувані поля й безпечні значення
function sanitizeImport(o) {
  if (!o || typeof o !== "object" || !Array.isArray(o.sites)) return null;
  const isStr = (v) => typeof v === "string";
  const num = (v, min, max) => typeof v === "number" && isFinite(v) && v >= min && v <= max;

  const siteList = [];
  const ids = new Set();
  for (const s of o.sites) {
    if (!s || !isStr(s.id) || !isStr(s.url) || !/^https?:\/\//i.test(s.url)) continue;
    if (ids.has(s.id)) continue;
    ids.add(s.id);
    const site = {
      id: s.id.slice(0, 64),
      url: s.url,
      title: (isStr(s.title) && s.title ? s.title : s.url).slice(0, 40)
    };
    if (isStr(s.folderId)) site.folderId = s.folderId;
    siteList.push(site);
  }

  const folderList = [];
  const fids = new Set();
  if (Array.isArray(o.folders)) {
    for (const f of o.folders) {
      if (f && isStr(f.id) && isStr(f.name) && f.name.trim() && !fids.has(f.id)) {
        fids.add(f.id);
        const nf = { id: f.id.slice(0, 64), name: f.name.slice(0, 30) };
        if (isStr(f.color) && /^#[0-9a-fA-F]{6}$/.test(f.color)) nf.color = f.color;
        if (f.label === true) nf.label = true;
        folderList.push(nf);
      }
    }
  }
  for (const s of siteList) if (s.folderId && !fids.has(s.folderId)) delete s.folderId;

  const zoomsOut = {};
  if (o.zooms && typeof o.zooms === "object") {
    for (const [k, v] of Object.entries(o.zooms)) if (ids.has(k) && num(v, 0.25, 5)) zoomsOut[k] = v;
  }
  const deskOut = {};
  if (o.desk && typeof o.desk === "object") {
    for (const [k, v] of Object.entries(o.desk)) if (ids.has(k) && num(v, 300, 4000)) deskOut[k] = v;
  }
  // Якщо у файлі немає нотаток (старий експорт) — null, тоді поточні нотатки лишаються
  let notesListOut = null;
  let noteFoldersOut = [];
  let activeNoteIdOut = null;
  if (Array.isArray(o.noteFolders)) {
    const nf = new Set();
    for (const f of o.noteFolders) {
      if (f && isStr(f.id) && isStr(f.name) && f.name.trim() && !nf.has(f.id)) {
        nf.add(f.id);
        noteFoldersOut.push({ id: f.id.slice(0, 64), name: f.name.slice(0, 30), open: f.open === true });
      }
    }
  }
  if (Array.isArray(o.notesList) && o.notesList.length > 0) {
    notesListOut = [];
    const nids = new Set();
    const fileIds = new Set();
    for (const n of o.notesList) {
      if (!n || !isStr(n.id) || nids.has(n.id)) continue;
      nids.add(n.id);
      const out = { id: n.id.slice(0, 64), text: isStr(n.text) ? n.text : "" };
      if (isStr(n.title)) out.title = n.title.slice(0, 100);   // старий формат — зведеться в migrateNotes
      if (num(n.created, 0, 1e14)) out.created = n.created;
      if (num(n.modified, 0, 1e14)) out.modified = n.modified;
      if (num(n.trashed, 1, 1e14)) out.trashed = n.trashed;
      if (isStr(n.folderId) && noteFoldersOut.some((f) => f.id === n.folderId)) out.folderId = n.folderId;
      if (isStr(n.url) && /^https?:\/\//i.test(n.url)) out.url = n.url.slice(0, 2000);
      if (Array.isArray(n.files)) {
        const fl = [];
        for (const f of n.files) {
          if (fl.length >= 50) break;
          if (f && isStr(f.id) && !fileIds.has(f.id) && isStr(f.data) && f.data.length < 14e6 && /^data:[^,]*;base64,/.test(f.data)) {
            fileIds.add(f.id);
            fl.push({
              id: f.id.slice(0, 64),
              name: (isStr(f.name) && f.name ? f.name : "file").slice(0, 120),
              type: isStr(f.type) ? f.type.slice(0, 100) : "application/octet-stream",
              size: 0,
              data: f.data
            });
          }
        }
        if (fl.length) out.files = fl;
      }
      notesListOut.push(out);
    }
    if (notesListOut.length) migrateNotes(notesListOut); else notesListOut = null;
  }
  if (notesListOut) {
    activeNoteIdOut = isStr(o.activeNoteId) ? o.activeNoteId : notesListOut[0].id;
    if (!notesListOut.find(n => n.id === activeNoteIdOut)) activeNoteIdOut = notesListOut[0].id;
  }

  return {
    sites: siteList,
    folders: folderList,
    zooms: zoomsOut,
    desk: deskOut,
    notesList: notesListOut,
    noteFolders: notesListOut ? noteFoldersOut : null,
    notesSort: ["modified", "created", "title"].includes(o.notesSort) ? o.notesSort : null,
    activeNoteId: activeNoteIdOut,
    lang: o.lang === "en" || o.lang === "uk" ? o.lang : null,
    activeId: isStr(o.activeId) && ids.has(o.activeId) ? o.activeId : (siteList[0] ? siteList[0].id : null)
  };
}

function handleImportText(text) {
  let data = null;
  try { data = sanitizeImport(JSON.parse(text)); } catch (e) {}
  if (!data) {
    openDrop({ type: "settings", msg: t("importBad"), err: true });
    return;
  }
  openDrop({ type: "import-confirm", data });
}

async function applyImport(d) {
  sites = d.sites;
  folders = d.folders;
  zooms = d.zooms;
  desk = d.desk;
  activeId = d.activeId;
  if (d.notesList) {
    try {
      await fileClear();
      for (const n of d.notesList) {
        if (!n.files) continue;
        const keep = [];
        for (const f of n.files) {
          const b = dataUrlToBlob(f.data, f.type);
          if (b) { await filePut(f.id, b); keep.push({ id: f.id, name: f.name, type: f.type, size: b.size }); }
        }
        if (keep.length) n.files = keep; else delete n.files;
      }
    } catch (e) {
      console.error("import files failed:", e);
      for (const n of d.notesList) delete n.files;
    }
    notesList = d.notesList;
    noteFolders = d.noteFolders || [];
    activeNoteId = d.activeNoteId;
  }
  if (d.notesSort) notesSort = d.notesSort;
  if (noteSaveTimer) { clearTimeout(noteSaveTimer); noteSaveTimer = null; }
  const payload = { sites, folders, zooms, desk, activeId, notesList, noteFolders, notesSort, activeNoteId };
  if (d.lang) { payload.lang = d.lang; LANG = d.lang; }
  await browser.storage.local.set(payload);
  applyI18n();
  openDrop({ type: "settings", msg: t("imported") });
}

(async function init() {
  await loadLang();
  applyI18n();
  const d = await browser.storage.local.get(["baseDpr", "zooms", "desk"]);
  if (d.baseDpr) {
    baseDpr = d.baseDpr;
  } else {
    baseDpr = window.devicePixelRatio || 1;
    await browser.storage.local.set({ baseDpr });
  }
  zooms = d.zooms || {};
  desk = d.desk || {};
  lastNative = nativeZoom();
  await readSites();
  render();
})();


// --- Зв'язок із фоновою сторінкою (команди розкладки/транслітерації) ---
(function connectToBackground() {
  let port;
  try { port = browser.runtime.connect({ name: "my-sidebar-panel" }); } catch (e) { return; }
  browser.windows.getCurrent().then((w) => port.postMessage({ windowId: w.id })).catch(() => {});
  port.onMessage.addListener((m) => {
    if (m && m.cmd === "close") { window.close(); return; }   // лише Chromium: sidePanel не закривається ззовні
    if (m && (m.cmd === "fix-layout" || m.cmd === "translit")) {
      if (typeof runTool === "function" && runTool(m.cmd)) return;
      const f = frames.get(activeId);
      if (f && f.contentWindow) f.contentWindow.postMessage({ __sis: 1, cmd: m.cmd }, "*");
    } });
  port.onDisconnect.addListener(() => setTimeout(connectToBackground, 500));
})();


// --- Text Tools for Sidebar UI (Notes, inputs) ---
const EN = "qwertyuiop[]asdfghjkl;'zxcvbnm,./`\\" + 'QWERTYUIOP{}ASDFGHJKL:\"ZXCVBNM<>?~|';
const UK = "йцукенгшщзхїфівапролджєячсмитьбю.'ґ" + "ЙЦУКЕНГШЩЗХЇФІВАПРОЛДЖЄЯЧСМИТЬБЮ,ʼҐ";

const enToUk = {};
const ukToEn = {};
for (let i = 0; i < EN.length; i++) {
  enToUk[EN[i]] = UK[i];
  if (/[а-щьюяєіїґА-ЩЬЮЯЄІЇҐ]/.test(UK[i])) ukToEn[UK[i]] = EN[i];
}
ukToEn["'"] = "`";

function convertLayout(text) {
  const latin = (text.match(/[A-Za-z]/g) || []).length;
  const cyr = (text.match(/[А-Яа-яЄєІіЇїҐґ]/g) || []).length;
  const map = latin >= cyr ? enToUk : ukToEn;
  return Array.from(text, ch => map[ch] ?? ch).join("");
}

function transliterate(str) {
  let res = str.replace(/(^|[^А-Яа-яЄєІіЇїҐґ])([ЄєЇїЙйЮюЯя])/g, (m, p, l) => {
    const sm = {'Є':'Ye','є':'ye','Ї':'Yi','ї':'yi','Й':'Y','й':'y','Ю':'Yu','ю':'yu','Я':'Ya','я':'ya'};
    return p + sm[l];
  });
  res = res.replace(/Зг/g, "Zgh").replace(/ЗГ/g, "ZGH").replace(/зг/g, "zgh");
  const map = {
    'А':'A','а':'a','Б':'B','б':'b','В':'V','в':'v','Г':'H','г':'h','Ґ':'G','ґ':'g',
    'Д':'D','д':'d','Е':'E','е':'e','Ж':'Zh','ж':'zh','З':'Z','з':'z','И':'Y','и':'y',
    'І':'I','і':'i','К':'K','к':'k','Л':'L','л':'l','М':'M','м':'m','Н':'N','н':'n',
    'О':'O','о':'o','П':'P','п':'p','Р':'R','р':'r','С':'S','с':'s','Т':'T','т':'t',
    'У':'U','у':'u','Ф':'F','ф':'f','Х':'Kh','х':'kh','Ц':'Ts','ц':'ts','Ч':'Ch','ч':'ch',
    'Ш':'Sh','ш':'sh','Щ':'Shch','щ':'shch',
    'Є':'Ie','є':'ie','Ї':'I','ї':'i','Й':'I','й':'i','Ю':'Iu','ю':'iu','Я':'Ia','я':'ia'
  };
  res = res.replace(/[А-ЩЬЮЯа-щьюяҐґІіЇїЄє]/g, (m) => map[m] || m);
  res = res.replace(/['ʼьЬ]/g, '');
  return res;
}

function processText(el, type) {
  let start = el.selectionStart, end = el.selectionEnd;
  if (start === end) { start = 0; end = el.value.length; }
  const text = el.value.slice(start, end);
  const fixed = type === 'translit' ? transliterate(text) : convertLayout(text);
  el.setRangeText(fixed, start, end, "select");
  el.dispatchEvent(new Event("input", { bubbles: true }));
}

function processEditable(root, type) {
  const sel = window.getSelection();
  if (sel.isCollapsed) {
    const range = document.createRange();
    range.selectNodeContents(root);
    sel.removeAllRanges();
    sel.addRange(range);
  }
  const text = sel.toString();
  const fixed = type === 'translit' ? transliterate(text) : convertLayout(text);
  document.execCommand("insertText", false, fixed);
}

function runTool(type) {
  const el = document.activeElement;
  if (!el) return false;
  if ((el.tagName === "TEXTAREA") ||
      (el.tagName === "INPUT" && /^(text|search|url|email)?$/.test(el.type))) {
    processText(el, type);
    return true;
  }
  if (el.isContentEditable) {
    processEditable(el, type);
    return true;
  }
  return false;
}

// ===================== Нотатки (дерево, теки, кошик) =====================
let syncEnabled = false;
let syncStatus = null;
let noteFolders = [];      // [{ id, name, open }]
let notesSort = "modified"; // modified | created | title
let noteQuery = "";
let trashOpen = false;
let trashConfirm = false;
let notesMd = false;
let notesExpanded = false;
let renameFolderId = null;
let noteSaveTimer = null;
let dragNoteId = null;

function flushNotes() {
  if (noteSaveTimer) { clearTimeout(noteSaveTimer); noteSaveTimer = null; }
  return browser.storage.local.set({ notesList, noteFolders, activeNoteId, notesSort });
}
function persistNotes(immediate) {
  if (immediate) return flushNotes();
  if (noteSaveTimer) clearTimeout(noteSaveTimer);
  noteSaveTimer = setTimeout(flushNotes, 300);
}
window.addEventListener("pagehide", () => { if (noteSaveTimer) flushNotes(); });

// Старі нотатки мали окреме поле title; тепер назва = перший рядок тексту.
function migrateNotes(list) {
  const def = /^(Нотатка|Note)( \d+)?$/;
  let changed = false;
  for (const n of list) {
    if (typeof n.text !== "string") { n.text = ""; changed = true; }
    if (!isFinite(n.created)) {
      const fromId = Number(String(n.id).slice(1));
      n.created = fromId > 1e12 ? fromId : Date.now();
      changed = true;
    }
    if (!isFinite(n.modified)) { n.modified = n.created; changed = true; }
    if ("title" in n) {
      const ttl = typeof n.title === "string" ? n.title.trim() : "";
      if (ttl && !def.test(ttl) && n.text.split("\n")[0].trim() !== ttl) {
        n.text = ttl + (n.text ? "\n" + n.text : "");
      }
      delete n.title;
      changed = true;
    }
  }
  return changed;
}

function noteLabel(n) {
  const line = (n.text || "").split("\n").map((s) => s.trim()).find(Boolean);
  return line || t("noteEmpty");
}

function fmtDate(ms) {
  try {
    return new Date(ms).toLocaleString(LANG === "uk" ? "uk-UA" : "en-GB", { dateStyle: "short", timeStyle: "medium" });
  } catch (e) { return new Date(ms).toLocaleString(); }
}

function mdToHtml(src) {
  const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const inline = (raw) => {
    let s = esc(raw);
    const codes = [];
    s = s.replace(/`([^`]+)`/g, (m, c) => { codes.push(c); return "\u0001" + (codes.length - 1) + "\u0001"; });
    s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
    s = s.replace(/(^|[\s(])(https?:\/\/[^\s<)]+)/g, '$1<a href="$2" target="_blank" rel="noopener">$2</a>');
    s = s.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    s = s.replace(/(^|[^*])\*([^*\s][^*]*)\*/g, "$1<em>$2</em>");
    return s.replace(/\u0001(\d+)\u0001/g, (m, i) => "<code>" + codes[i] + "</code>");
  };
  const out = [];
  let para = [], list = null, inCode = false, code = [];
  const flushP = () => { if (para.length) { out.push("<p>" + para.map(inline).join("<br>") + "</p>"); para = []; } };
  const flushL = () => { if (list) { out.push("</" + list + ">"); list = null; } };
  for (const line of String(src).replace(/\r/g, "").split("\n")) {
    if (inCode) {
      if (/^```/.test(line)) { out.push("<pre><code>" + esc(code.join("\n")) + "</code></pre>"); code = []; inCode = false; }
      else code.push(line);
      continue;
    }
    let m;
    if (/^```/.test(line)) { flushP(); flushL(); inCode = true; }
    else if ((m = line.match(/^(#{1,6})\s+(.*)$/))) { flushP(); flushL(); out.push("<h" + m[1].length + ">" + inline(m[2]) + "</h" + m[1].length + ">"); }
    else if (/^\s*([-*_])\1\1+\s*$/.test(line)) { flushP(); flushL(); out.push("<hr>"); }
    else if ((m = line.match(/^\s*[-*+]\s+(.*)$/))) { flushP(); if (list !== "ul") { flushL(); out.push("<ul>"); list = "ul"; } out.push("<li>" + inline(m[1].replace(/^\[( |x|X)\]\s+/, (a, c) => (c === " " ? "☐ " : "☑ "))) + "</li>"); }
    else if ((m = line.match(/^\s*\d+[.)]\s+(.*)$/))) { flushP(); if (list !== "ol") { flushL(); out.push("<ol>"); list = "ol"; } out.push("<li>" + inline(m[1]) + "</li>"); }
    else if ((m = line.match(/^>\s?(.*)$/))) { flushP(); flushL(); out.push("<blockquote>" + inline(m[1]) + "</blockquote>"); }
    else if (!line.trim()) { flushP(); flushL(); }
    else { flushL(); para.push(line); }
  }
  if (inCode) out.push("<pre><code>" + esc(code.join("\n")) + "</code></pre>");
  flushP(); flushL();
  return out.join("");
}


// ===================== Вкладення нотаток (IndexedDB) =====================
// Самі файли лежать в IndexedDB, у нотатці — лише метадані n.files = [{ id, name, type, size }],
// щоб збереження тексту не тягнуло за собою мегабайти.
const MAX_FILE = 10 * 1024 * 1024;
const IMG_RE = /^image\/(png|jpeg|gif|webp|svg\+xml|avif|bmp)$/;
let lightbox = null; // функція закриття перегляду зображення, якщо він відкритий
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && lightbox) { e.stopImmediatePropagation(); lightbox(); }
}, true);

let _filesDb = null;
function filesDb() {
  if (!_filesDb) {
    _filesDb = new Promise((res, rej) => {
      const r = indexedDB.open("my-sidebar-files", 1);
      r.onupgradeneeded = () => r.result.createObjectStore("files");
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
  }
  return _filesDb;
}
async function fileOp(mode, fn) {
  const db = await filesDb();
  return new Promise((res, rej) => {
    const tx = db.transaction("files", mode);
    const rq = fn(tx.objectStore("files"));
    tx.oncomplete = () => res(rq && rq.result);
    tx.onerror = tx.onabort = () => rej(tx.error);
  });
}
const filePut = (id, blob) => fileOp("readwrite", (s) => s.put(blob, id));
const fileGet = (id) => fileOp("readonly", (s) => s.get(id));
const fileDel = (id) => fileOp("readwrite", (s) => s.delete(id));
const fileClear = () => fileOp("readwrite", (s) => s.clear());
function dropNoteFiles(list) {
  for (const n of list) for (const f of (n.files || [])) fileDel(f.id).catch(() => {});
}

function fmtSize(b) {
  if (b < 1024) return b + " B";
  if (b < 1048576) return Math.round(b / 1024) + " KB";
  return (b / 1048576).toFixed(1) + " MB";
}
function dataUrlToBlob(dataUrl, type) {
  const m = /^data:[^,]*;base64,([\s\S]*)$/.exec(dataUrl || "");
  if (!m) return null;
  try {
    const bin = atob(m[1]);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return new Blob([arr], { type: type || "application/octet-stream" });
  } catch (e) { return null; }
}
function blobToDataUrl(blob) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = () => rej(r.error);
    r.readAsDataURL(blob);
  });
}

// ===================== Імпорт із Google Keep (Takeout .zip) =====================
// Takeout кладе кожну нотатку окремим .json (Takeout/Keep/*.json) разом із вкладеннями.
// ZIP читаємо вручну (центральний каталог + DecompressionStream), читаючи з файлу лише потрібні шматки.
async function readZipEntries(file) {
  const size = file.size;
  const tailLen = Math.min(size, 65535 + 22 + 20);
  const tail = new DataView(await file.slice(size - tailLen).arrayBuffer());
  let eocd = -1;
  for (let i = tail.byteLength - 22; i >= 0; i--) {
    if (tail.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error("not a zip");
  let count = tail.getUint16(eocd + 10, true);
  let cdSize = tail.getUint32(eocd + 12, true);
  let cdOffset = tail.getUint32(eocd + 16, true);
  if (count === 0xffff || cdSize === 0xffffffff || cdOffset === 0xffffffff) {
    const loc = eocd - 20;   // ZIP64 end of central directory locator
    if (loc < 0 || tail.getUint32(loc, true) !== 0x07064b50) throw new Error("bad zip64");
    const z64 = Number(tail.getBigUint64(loc + 8, true));
    const z = new DataView(await file.slice(z64, z64 + 56).arrayBuffer());
    if (z.getUint32(0, true) !== 0x06064b50) throw new Error("bad zip64");
    count = Number(z.getBigUint64(32, true));
    cdSize = Number(z.getBigUint64(40, true));
    cdOffset = Number(z.getBigUint64(48, true));
  }
  const cd = new DataView(await file.slice(cdOffset, cdOffset + cdSize).arrayBuffer());
  const dec = new TextDecoder("utf-8");
  const entries = [];
  let p = 0;
  for (let i = 0; i < count && p + 46 <= cd.byteLength; i++) {
    if (cd.getUint32(p, true) !== 0x02014b50) break;
    const flags = cd.getUint16(p + 8, true);
    const method = cd.getUint16(p + 10, true);
    let csize = cd.getUint32(p + 20, true);
    let usize = cd.getUint32(p + 24, true);
    const nlen = cd.getUint16(p + 28, true);
    const elen = cd.getUint16(p + 30, true);
    const clen = cd.getUint16(p + 32, true);
    let off = cd.getUint32(p + 42, true);
    const name = dec.decode(new Uint8Array(cd.buffer, cd.byteOffset + p + 46, nlen));
    if (usize === 0xffffffff || csize === 0xffffffff || off === 0xffffffff) {
      let q = p + 46 + nlen;
      const end = q + elen;
      while (q + 4 <= end) {
        const id = cd.getUint16(q, true), len = cd.getUint16(q + 2, true);
        if (id === 1) {
          let r = q + 4;
          if (usize === 0xffffffff) { usize = Number(cd.getBigUint64(r, true)); r += 8; }
          if (csize === 0xffffffff) { csize = Number(cd.getBigUint64(r, true)); r += 8; }
          if (off === 0xffffffff) { off = Number(cd.getBigUint64(r, true)); }
        }
        q += 4 + len;
      }
    }
    entries.push({ name, method, csize, usize, off, encrypted: !!(flags & 1) });
    p += 46 + nlen + elen + clen;
  }
  return entries;
}

async function zipEntryBlob(file, e, type) {
  if (e.encrypted) throw new Error("encrypted");
  const lh = new DataView(await file.slice(e.off, e.off + 30).arrayBuffer());
  if (lh.getUint32(0, true) !== 0x04034b50) throw new Error("bad entry");
  const start = e.off + 30 + lh.getUint16(26, true) + lh.getUint16(28, true);
  const raw = file.slice(start, start + e.csize);
  if (e.method === 0) return raw.slice(0, raw.size, type || "");
  if (e.method === 8) {
    const out = await new Response(raw.stream().pipeThrough(new DecompressionStream("deflate-raw"))).blob();
    return out.slice(0, out.size, type || "");
  }
  throw new Error("method " + e.method);
}

// Повертає { notes, files, dup, skippedFiles }. Нічого не видаляє, лише додає (дублікати за датою й текстом пропускає).
async function importKeepZip(file, onProgress) {
  const entries = (await readZipEntries(file)).filter((e) => !e.name.endsWith("/") && !e.name.startsWith("__MACOSX/"));
  const jsons = entries.filter((e) => /\.json$/i.test(e.name) && e.usize < 5e6);
  const baseOf = (n) => n.slice(n.lastIndexOf("/") + 1);
  const byPath = new Map(entries.map((e) => [e.name, e]));
  const byStem = new Map();   // «папка/ім'я без розширення» → запис: Keep інколи називає .jpeg замість .jpg
  for (const e of entries) {
    const stem = e.name.replace(/\.[^./]+$/, "");
    if (!byStem.has(stem)) byStem.set(stem, e);
  }
  const stats = { notes: 0, files: 0, dup: 0, skippedFiles: 0 };
  const have = new Set(notesList.map((n) => n.created + "|" + n.text));
  const ids = new Set(notesList.map((n) => n.id));
  const now = Date.now();
  let seq = 0;
  const folderByName = (name) => {
    let f = noteFolders.find((x) => x.name.toLowerCase() === name.toLowerCase());
    if (!f) {
      f = { id: "f" + now + "k" + (++seq), name: name.slice(0, 30), open: false };
      noteFolders.push(f);
    }
    return f;
  };
  const fresh = [];

  for (let i = 0; i < jsons.length; i++) {
    if (onProgress) onProgress(i, jsons.length);
    const e = jsons[i];
    let j;
    try { j = JSON.parse(await (await zipEntryBlob(file, e, "application/json")).text()); } catch (err) { continue; }
    if (!j || typeof j !== "object" ||
        !("userEditedTimestampUsec" in j || "textContent" in j || "listContent" in j)) continue;

    const title = typeof j.title === "string" ? j.title.trim() : "";
    let body = "";
    if (Array.isArray(j.listContent) && j.listContent.length) {
      body = j.listContent.map((it) => "- [" + (it && it.isChecked ? "x" : " ") + "] " + String((it && it.text) || "")).join("\n");
    } else if (typeof j.textContent === "string") {
      body = j.textContent.replace(/\r\n?/g, "\n").trimEnd();
    }
    const links = [];
    let url = "";
    for (const a of (Array.isArray(j.annotations) ? j.annotations : [])) {
      if (a && typeof a.url === "string" && /^https?:\/\//i.test(a.url)) {
        links.push("🔗 " + (a.title ? a.title + " — " : "") + a.url);
        if (!url) url = a.url.slice(0, 2000);
      }
    }
    const labels = (Array.isArray(j.labels) ? j.labels : []).map((l) => l && l.name).filter((x) => typeof x === "string" && x.trim());
    const parts = [];
    if (title) parts.push(title);
    if (body.trim()) parts.push(body);
    if (links.length) parts.push(links.join("\n"));
    if (labels.length > 1) parts.push(labels.slice(1).map((l) => "#" + l.trim().replace(/\s+/g, "_")).join(" "));
    const text = parts.join("\n\n");

    const att = Array.isArray(j.attachments) ? j.attachments.slice(0, 50) : [];
    if (!text.trim() && !att.length) continue;

    const usec = (v) => (typeof v === "number" && v > 0 ? Math.round(v / 1000) : 0);
    const created = usec(j.createdTimestampUsec) || usec(j.userEditedTimestampUsec) || now;
    const modified = usec(j.userEditedTimestampUsec) || created;
    if (have.has(created + "|" + text)) { stats.dup++; continue; }

    const n = { id: "", text, created, modified };
    let nid = "n" + created + "k" + (seq++);
    while (ids.has(nid)) nid = "n" + created + "k" + (seq++);
    ids.add(nid);
    n.id = nid;
    if (url) n.url = url;
    if (j.isTrashed) n.trashed = modified;
    if (labels.length) n.folderId = folderByName(labels[0].trim()).id;
    else if (j.isArchived) n.folderId = folderByName("Keep: " + (LANG === "uk" ? "архів" : "archive")).id;

    const dir = e.name.slice(0, e.name.lastIndexOf("/") + 1);
    for (const a of att) {
      const fp = a && typeof a.filePath === "string" ? a.filePath : "";
      const fe = fp && (byPath.get(dir + fp) || byStem.get(dir + fp.replace(/\.[^./]+$/, "")));
      if (!fe || fe.usize > MAX_FILE) { stats.skippedFiles++; continue; }
      try {
        const type = typeof a.mimetype === "string" && a.mimetype ? a.mimetype : "application/octet-stream";
        const blob = await zipEntryBlob(file, fe, type);
        const fid = "a" + now + "k" + (seq++);
        await filePut(fid, blob);
        (n.files = n.files || []).push({ id: fid, name: baseOf(fe.name).slice(0, 120), type, size: blob.size });
        stats.files++;
      } catch (err) { stats.skippedFiles++; }
    }
    fresh.push(n);
    have.add(created + "|" + text);
  }
  if (fresh.length) {
    notesList.push(...fresh);
    stats.notes = fresh.length;
    persistNotes(true);
  }
  return stats;
}

function buildNotesPanel() {
  drop.classList.add("notes");
  lightbox = null;
  const el = (tag, cls, txt) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (txt != null) e.textContent = txt;
    return e;
  };
  const ibtn = (content, title, fn) => {
    const b = el("button", "nt-ibtn");
    if (typeof content === "string") b.textContent = content; else b.append(content);
    b.title = title;
    b.onclick = (e) => { e.stopPropagation(); fn(); };
    return b;
  };
  const docIcon = () => svgEl([
    { d: "M7 3h7l4 4v14H7z", fill: "none", stroke: "currentColor", "stroke-width": "1.6", "stroke-linejoin": "round" },
    { d: "M9.5 12h6M9.5 15.5h6M9.5 8.5h3", fill: "none", stroke: "currentColor", "stroke-width": "1.4", "stroke-linecap": "round" }
  ]);
  const trashIcon = () => svgEl([
    { d: "M5 7h14M10 7V5h4v2M7 7l1 13h8l1-13M10 11v6M14 11v6", fill: "none", stroke: "currentColor", "stroke-width": "1.5", "stroke-linecap": "round", "stroke-linejoin": "round" }
  ]);
  const camIcon = () => svgEl([
    { d: "M4 8h3l1.5-2h7L17 8h3v11H4z", fill: "none", stroke: "currentColor", "stroke-width": "1.5", "stroke-linejoin": "round" },
    { d: "M12 16.5a3 3 0 1 0 0-6 3 3 0 0 0 0 6z", fill: "none", stroke: "currentColor", "stroke-width": "1.5" }
  ]);
  const clipIcon = () => svgEl([
    { d: "M20 11.5l-8 8a5 5 0 0 1-7-7l8.5-8.5a3.2 3.2 0 0 1 4.5 4.5L9.5 17a1.4 1.4 0 0 1-2-2L15 7.5", fill: "none", stroke: "currentColor", "stroke-width": "1.5", "stroke-linecap": "round", "stroke-linejoin": "round" }
  ]);
  const linkIcon = () => svgEl([
    { d: "M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1", fill: "none", stroke: "currentColor", "stroke-width": "1.6", "stroke-linecap": "round" }
  ]);

  const cur = () => notesList.find((n) => n.id === activeNoteId) || null;
  const touch = (n) => { n.modified = Date.now(); };
  const pickActive = () => {
    const n = notesList.find((x) => !x.trashed) || notesList[0];
    activeNoteId = n ? n.id : null;
  };

  const wrap = el("div", "nt-wrap");

  // --- Заголовок ---
  const hd = el("div", "nt-head");
  const importIcon = () => svgEl([
    { d: "M12 4v10M8 10.5l4 4 4-4M5 19h14", fill: "none", stroke: "currentColor", "stroke-width": "1.6", "stroke-linecap": "round", "stroke-linejoin": "round" }
  ]);
  const keepBtn = ibtn(importIcon(), t("noteImportKeep"), () => keepInput.click());
  keepBtn.classList.add("nt-close");
  const keepInput = el("input");
  keepInput.type = "file"; keepInput.accept = ".zip,application/zip"; keepInput.hidden = true;
  keepInput.onchange = async () => {
    const f = keepInput.files[0];
    keepInput.value = "";
    if (!f) return;
    keepBtn.disabled = true;
    try {
      const st = await importKeepZip(f, (i, n) => flash(t("keepProgress", i + 1, n), false, 60000));
      if (!st.notes && !st.dup) flash(t("keepNone"), true, 8000);
      else {
        flash(t("keepDone", st.notes, st.files, st.dup) + (st.skippedFiles ? " " + t("keepSkippedFiles", st.skippedFiles) : ""), false, 10000);
      }
      noteQuery = ""; search.value = "";
      if (!cur()) pickActive();
      renderList(); loadEditor();
    } catch (e) {
      flash(t("keepFail", String((e && e.message) || e).slice(0, 80)), true, 8000);
    }
    keepBtn.disabled = false;
  };
  hd.append(el("span", "nt-title", t("notesTitle").replace(/^\S+\s/, "")), keepBtn, ibtn("×", t("cancel"), closeDrop), keepInput);
  hd.children[2].classList.add("nt-close");

  // --- Пошук + кнопки ---
  const bar = el("div", "nt-bar");
  const search = el("input");
  search.type = "text";
  search.placeholder = t("noteSearch");
  search.value = noteQuery;
  const btnAdd = ibtn("+", t("addNote"), () => {
    const now = Date.now();
    const n = { id: "n" + now, text: "", created: now, modified: now };
    const c = cur();
    if (c && !c.trashed && c.folderId && noteFolders.some((f) => f.id === c.folderId)) {
      n.folderId = c.folderId;
      const f = noteFolders.find((x) => x.id === c.folderId);
      if (f) f.open = true;
    }
    notesList.push(n);
    activeNoteId = n.id;
    noteQuery = ""; search.value = "";
    notesMd = false;
    persistNotes(true);
    renderList(); loadEditor();
    if (!ta.hidden) ta.focus();
  });
  const btnDel = ibtn("−", t("noteToTrash"), () => {
    const c = cur();
    if (!c) return;
    if (c.trashed) { dropNoteFiles([c]); notesList = notesList.filter((n) => n.id !== c.id); }
    else c.trashed = Date.now();
    pickActive();
    persistNotes(true);
    renderList(); loadEditor();
  });
  const btnFolder = ibtn(folderPlusIcon(), t("noteNewFolder"), () => {
    const f = { id: "f" + Date.now(), name: t("noteFolderDefault") + " " + (noteFolders.length + 1), open: true };
    noteFolders.push(f);
    renameFolderId = f.id;
    persistNotes(true);
    renderList();
  });
  bar.append(search, btnAdd, btnDel, btnFolder);

  // --- Сортування ---
  const sortSel = el("select", "nt-sort");
  for (const [v, k] of [["modified", "noteSortModified"], ["created", "noteSortCreated"], ["title", "noteSortTitle"]]) {
    const o = el("option", null, t(k));
    o.value = v;
    if (v === notesSort) o.selected = true;
    sortSel.append(o);
  }
  sortSel.onchange = () => { notesSort = sortSel.value; persistNotes(true); renderList(); };

  // --- Список ---
  const list = el("div", "nt-list");

  // --- Панель інструментів ---
  const tools = el("div", "nt-tools");
  const mdBtn = ibtn("M↓", t("noteMd"), () => { notesMd = !notesMd; applyMode(); });
  mdBtn.classList.add("nt-md");
  const restoreBtn = ibtn("↩", t("noteRestore"), () => {
    const c = cur();
    if (!c || !c.trashed) return;
    delete c.trashed;
    persistNotes(true);
    renderList(); loadEditor();
  });
  const expandBtn = ibtn("⤢", t("noteExpand"), () => { notesExpanded = !notesExpanded; applyMode(); });
  const spacer = el("span", "nt-spacer");
  const shotBtn = ibtn(camIcon(), t("noteShot"), () => shot());
  const attachBtn = ibtn(clipIcon(), t("noteAttach"), () => fileInput.click());
  const fileInput = el("input");
  fileInput.type = "file"; fileInput.multiple = true; fileInput.hidden = true;
  fileInput.onchange = () => { addFiles(Array.from(fileInput.files)); fileInput.value = ""; };
  tools.append(shotBtn, attachBtn, mdBtn, restoreBtn, spacer, expandBtn, fileInput);

  // --- Редактор і перегляд ---
  const ta = el("textarea", "nt-ta");
  ta.placeholder = t("notesPlaceholder");
  const prev = el("div", "nt-prev");
  prev.hidden = true;
  prev.ondblclick = () => { if (notesMd) { notesMd = false; applyMode(); ta.focus(); } };
  prev.onclick = (e) => {
    const a = e.target.closest && e.target.closest("a");
    if (a) { e.preventDefault(); browser.tabs.create({ url: a.href }); }
  };

  const filesBox = el("div", "nt-files");
  filesBox.hidden = true;
  const msg = el("div", "nt-msg");
  msg.hidden = true;

  // --- Підвал: адреса, дати ---
  const foot = el("div", "nt-foot");
  const addrRow = el("div", "nt-addr");
  const addr = el("input");
  addr.type = "text";
  addr.placeholder = t("noteAddress");
  const openBtn = ibtn(linkIcon(), t("noteOpenAddr"), () => {
    const u = addr.value.trim();
    if (/^https?:\/\//i.test(u)) browser.tabs.create({ url: u });
  });
  const fillBtn = ibtn("⌖", t("noteAddrFill"), async () => {
    const c = cur();
    if (!c || c.trashed) return;
    const [tab] = await browser.tabs.query({ active: true, lastFocusedWindow: true });
    if (tab && /^https?:\/\//i.test(tab.url || "")) {
      addr.value = c.url = tab.url;
      persistNotes();
    }
  });
  addrRow.append(openBtn, addr, fillBtn);
  const stamps = el("div", "nt-stamps");
  foot.append(addrRow, stamps);

  wrap.append(hd, bar, sortSel, list, tools, ta, prev, filesBox, msg, foot);
  drop.append(wrap);

  // ---------- вкладення ----------
  let thumbUrls = [];
  let msgTimer = null;
  function flash(text, err, ms) {
    clearTimeout(msgTimer);
    msg.textContent = text;
    msg.hidden = !text;
    msg.classList.toggle("err", !!err);
    if (text) msgTimer = setTimeout(() => { msg.hidden = true; }, ms || 4000);
  }

  async function addFiles(fileList) {
    const n = cur();
    if (!n || n.trashed) return;
    let added = 0;
    for (const f of fileList) {
      if (f.size > MAX_FILE) { flash(t("noteFileTooBig", f.name || "file"), true); continue; }
      const id = "a" + Date.now() + Math.random().toString(36).slice(2, 6);
      try { await filePut(id, f); } catch (e) { flash(String(e), true); continue; }
      (n.files = n.files || []).push({
        id, name: (f.name || "file").slice(0, 120), type: f.type || "application/octet-stream", size: f.size
      });
      added++;
    }
    if (added) { touch(n); persistNotes(true); renderList(); }
    if (cur() === n) { renderFiles(); updateStamps(); }
  }

  async function shot() {
    const n = cur();
    if (!n || n.trashed) return;
    shotBtn.disabled = true;
    try {
      const w = await browser.windows.getCurrent();
      const dataUrl = await browser.tabs.captureVisibleTab(w.id, { format: "png" });
      const blob = dataUrlToBlob(dataUrl, "image/png");
      if (!blob) throw new Error("bad data");
      const d = new Date(), p = (x) => String(x).padStart(2, "0");
      const name = "screenshot-" + d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + "-" +
        p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds()) + ".png";
      await addFiles([new File([blob], name, { type: "image/png" })]);
    } catch (e) {
      flash(t("noteShotFail"), true);
    }
    const c = cur();
    shotBtn.disabled = !c || !!c.trashed;
  }

  async function openFile(f) {
    let blob = null;
    try { blob = await fileGet(f.id); } catch (e) {}
    if (!blob) { flash(t("noteFileMissing"), true); return; }
    const url = URL.createObjectURL(blob);
    const save = () => {
      const a = document.createElement("a");
      a.href = url; a.download = f.name;
      document.body.append(a); a.click(); a.remove();
    };
    if (!IMG_RE.test(f.type)) { save(); setTimeout(() => URL.revokeObjectURL(url), 5000); return; }
    const ov = el("div", "nt-lightbox");
    const close = () => { ov.remove(); URL.revokeObjectURL(url); lightbox = null; };
    const img = el("img");
    img.src = url; img.alt = f.name;
    const lbBar = el("div", "nt-lbbar");
    lbBar.append(el("span", "t", f.name + " (" + fmtSize(f.size) + ")"), ibtn("⬇", t("noteFileSave"), save), ibtn("×", t("cancel"), close));
    ov.onclick = (e) => { if (e.target === ov) close(); };
    ov.append(lbBar, img);
    wrap.append(ov);
    lightbox = close;
  }

  function renderFiles() {
    thumbUrls.forEach((u) => URL.revokeObjectURL(u));
    thumbUrls = [];
    filesBox.textContent = "";
    const n = cur();
    const files = (n && n.files) || [];
    filesBox.hidden = !files.length;
    for (const f of files) {
      const isImg = IMG_RE.test(f.type);
      const item = el("div", "nt-file" + (isImg ? " img" : ""));
      item.title = f.name + " (" + fmtSize(f.size) + ")";
      if (isImg) {
        const img = el("img");
        img.alt = f.name;
        item.append(img);
        fileGet(f.id).then((b) => {
          if (b) { const u = URL.createObjectURL(b); thumbUrls.push(u); img.src = u; }
        }).catch(() => {});
      } else {
        item.append(el("span", "nt-fico", "📄"), el("span", "nt-fname", f.name));
      }
      item.onclick = () => openFile(f);
      if (!n.trashed) {
        const x = el("span", "nt-fx", "×");
        x.title = t("noteFileDel");
        x.onclick = async (e) => {
          e.stopPropagation();
          n.files = n.files.filter((z) => z.id !== f.id);
          if (!n.files.length) delete n.files;
          touch(n);
          try { await fileDel(f.id); } catch (err) {}
          persistNotes(true);
          renderFiles(); renderList(); updateStamps();
        };
        item.append(x);
      }
      filesBox.append(item);
    }
  }

  // вставка зображення з буфера й перетягування файлів у редактор
  ta.onpaste = (e) => {
    const fl = e.clipboardData && e.clipboardData.files;
    if (fl && fl.length) { e.preventDefault(); addFiles(Array.from(fl)); }
  };
  const hasFiles = (e) => e.dataTransfer && Array.from(e.dataTransfer.types || []).includes("Files");
  for (const zone of [ta, prev, filesBox]) {
    zone.ondragover = (e) => { if (hasFiles(e)) e.preventDefault(); };
    zone.ondrop = (e) => { if (hasFiles(e)) { e.preventDefault(); addFiles(Array.from(e.dataTransfer.files)); } };
  }

  // ---------- логіка ----------
  function applyMode() {
    const n = cur();
    const showPrev = notesMd && n;
    ta.hidden = !!showPrev;
    prev.hidden = !showPrev;
    if (showPrev) setHtml(prev, mdToHtml(n.text));
    mdBtn.classList.toggle("on", !!showPrev);
    expandBtn.classList.toggle("on", notesExpanded);
    bar.hidden = sortSel.hidden = list.hidden = notesExpanded;
  }

  function loadEditor() {
    const n = cur();
    const none = !n;
    ta.disabled = none;
    ta.readOnly = !!(n && n.trashed);
    addr.disabled = none || !!(n && n.trashed);
    fillBtn.disabled = addr.disabled;
    ta.value = n ? n.text : "";
    addr.value = (n && n.url) || "";
    restoreBtn.hidden = !(n && n.trashed);
    btnDel.title = n && n.trashed ? t("noteDeleteForever") : t("noteToTrash");
    btnDel.disabled = none;
    shotBtn.disabled = attachBtn.disabled = none || !!(n && n.trashed);
    renderFiles();
    updateStamps();
    applyMode();
  }

  function updateStamps() {
    const n = cur();
    stamps.textContent = "";
    if (!n) return;
    const line = (k, v) => {
      const d = el("div");
      d.append(el("b", null, t(k) + ": "), document.createTextNode(fmtDate(v)));
      stamps.append(d);
    };
    line("noteCreated", n.created);
    if (n.modified && n.modified !== n.created) line("noteModified", n.modified);
  }

  function selectNote(id) {
    activeNoteId = id;
    persistNotes(true);
    renderList(); loadEditor();
  }

  function sortFn() {
    const loc = LANG === "uk" ? "uk" : "en";
    if (notesSort === "created") return (a, b) => (b.created || 0) - (a.created || 0);
    if (notesSort === "title") return (a, b) => noteLabel(a).localeCompare(noteLabel(b), loc);
    return (a, b) => (b.modified || 0) - (a.modified || 0);
  }

  function noteRow(n, child) {
    const r = el("div", "nt-row" + (n.id === activeNoteId ? " active" : "") + (child ? " child" : ""));
    r.append(docIcon(), el("span", "t", noteLabel(n)));
    if (n.files && n.files.length) r.append(el("span", "nt-clip", "📎"));
    r.title = noteLabel(n);
    r.onclick = () => selectNote(n.id);
    if (!n.trashed) {
      r.draggable = true;
      r.ondragstart = (e) => { dragNoteId = n.id; e.dataTransfer.setData("text/plain", n.id); e.dataTransfer.effectAllowed = "move"; };
      r.ondragend = () => { dragNoteId = null; list.querySelectorAll(".drop-into").forEach((x) => x.classList.remove("drop-into")); };
    }
    return r;
  }

  function folderRow(f, items, isOpen) {
    const r = el("div", "nt-row folder");
    const arrow = el("span", "nt-arrow", isOpen ? "▾" : "▸");
    const ico = folderIcon();
    r.append(arrow, ico);
    if (renameFolderId === f.id) {
      const inp = el("input", "nt-rename");
      inp.value = f.name;
      let done = false;
      const commit = (ok) => {
        if (done) return; done = true;
        renameFolderId = null;
        if (ok && inp.value.trim()) f.name = inp.value.trim().slice(0, 30);
        persistNotes(true);
        renderList();
      };
      inp.onblur = () => commit(true);
      inp.onkeydown = (e) => {
        e.stopPropagation();
        if (e.key === "Enter") commit(true);
        else if (e.key === "Escape") commit(false);
      };
      inp.onclick = (e) => e.stopPropagation();
      r.append(inp);
      setTimeout(() => { inp.focus(); inp.select(); }, 0);
    } else {
      const nm = el("span", "t", f.name);
      nm.ondblclick = (e) => { e.stopPropagation(); renameFolderId = f.id; renderList(); };
      r.append(nm);
    }
    r.append(el("span", "nt-badge", String(items.length)));
    const x = el("span", "nt-x", "×");
    x.title = t("noteDelFolder");
    x.onclick = (e) => {
      e.stopPropagation();
      for (const n of notesList) if (n.folderId === f.id) delete n.folderId;
      noteFolders = noteFolders.filter((z) => z.id !== f.id);
      persistNotes(true);
      renderList();
    };
    r.append(x);
    r.onclick = () => { f.open = !f.open; persistNotes(true); renderList(); };
    r.ondragover = (e) => { if (dragNoteId) { e.preventDefault(); e.stopPropagation(); r.classList.add("drop-into"); } };
    r.ondragleave = () => r.classList.remove("drop-into");
    r.ondrop = (e) => {
      e.preventDefault(); e.stopPropagation();
      const n = notesList.find((z) => z.id === dragNoteId);
      if (n) { n.folderId = f.id; f.open = true; persistNotes(true); renderList(); }
    };
    return r;
  }

  function renderList() {
    const keep = list.scrollTop;
    list.textContent = "";
    const q = noteQuery.trim().toLowerCase();
    const match = (n) => !q || (n.text || "").toLowerCase().includes(q);
    const cmp = sortFn();
    const live = notesList.filter((n) => !n.trashed && match(n)).sort(cmp);
    const trashed = notesList.filter((n) => n.trashed);
    const trashShown = trashed.filter(match).sort((a, b) => (b.trashed || 0) - (a.trashed || 0));

    const known = new Set(noteFolders.map((f) => f.id));
    const folderList = noteFolders.slice().sort((a, b) => a.name.localeCompare(b.name, LANG === "uk" ? "uk" : "en"));
    for (const f of folderList) {
      const items = live.filter((n) => n.folderId === f.id);
      if (q && !items.length) continue;
      const isOpen = q ? true : !!f.open;
      list.append(folderRow(f, items, isOpen));
      if (isOpen) for (const n of items) list.append(noteRow(n, true));
    }
    for (const n of live.filter((n) => !n.folderId || !known.has(n.folderId))) list.append(noteRow(n, false));

    // Кошик
    const tr = el("div", "nt-row trash");
    tr.append(el("span", "nt-arrow", trashOpen ? "▾" : "▸"), trashIcon(), el("span", "t", t("noteTrash")));
    if (trashOpen && trashed.length) {
      const clr = el("span", "nt-x show", trashConfirm ? t("noteEmptyTrashSure") : "✕");
      clr.title = t("noteEmptyTrash");
      clr.onclick = (e) => {
        e.stopPropagation();
        if (!trashConfirm) { trashConfirm = true; renderList(); return; }
        trashConfirm = false;
        dropNoteFiles(notesList.filter((n) => n.trashed));
        notesList = notesList.filter((n) => !n.trashed);
        if (!cur()) pickActive();
        persistNotes(true);
        renderList(); loadEditor();
      };
      tr.append(clr);
    }
    tr.append(el("span", "nt-badge", String(trashed.length)));
    tr.onclick = () => { trashOpen = !trashOpen; trashConfirm = false; renderList(); };
    list.append(tr);
    if (trashOpen) for (const n of trashShown) list.append(noteRow(n, true));

    list.scrollTop = keep;
  }

  // Перетягування на порожнє місце списку = винести з теки
  list.ondragover = (e) => { if (dragNoteId) e.preventDefault(); };
  list.ondrop = (e) => {
    e.preventDefault();
    const n = notesList.find((z) => z.id === dragNoteId);
    if (n && n.folderId) { delete n.folderId; persistNotes(true); renderList(); }
  };

  search.oninput = () => { noteQuery = search.value; renderList(); };
  ta.oninput = () => {
    const n = cur();
    if (!n || n.trashed) return;
    n.text = ta.value;
    touch(n);
    persistNotes();
    renderList();
    updateStamps();
  };
  addr.oninput = () => {
    const n = cur();
    if (!n || n.trashed) return;
    const v = addr.value.trim();
    if (v) n.url = v.slice(0, 2000); else delete n.url;
    persistNotes();
  };

  if (!cur()) pickActive();
  renderList();
  loadEditor();
  positionDrop();
  const n0 = cur();
  if (n0 && !n0.trashed && !ta.hidden) setTimeout(() => ta.focus(), 0);
}
